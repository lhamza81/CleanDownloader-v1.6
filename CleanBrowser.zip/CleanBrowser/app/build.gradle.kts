plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "com.example.cleanbrowser"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.example.cleandownloader"
        minSdk = 29
        targetSdk = 35
        // Always higher than the build before it (minutes since 1970), so a new build installs over the old one.
        versionCode = (System.currentTimeMillis() / 60_000L).toInt()
        versionName = "1.0"
    }
    // One fixed key for every build. Android only updates an app (keeping its data) when the key is the same;
    // builds made on a fresh machine otherwise get a new random key each time and must be uninstalled first.
    signingConfigs {
        create("app") {
            storeFile = file("keystore/cleandownloader.p12")
            storeType = "pkcs12"
            storePassword = "cleandownloader"
            keyAlias = "cleandownloader"
            keyPassword = "cleandownloader"
        }
    }
    buildTypes {
        debug {
            signingConfig = signingConfigs.getByName("app")
        }
        release {
            signingConfig = signingConfigs.getByName("app")
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"))
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures { compose = true }
}

dependencies {
    val composeBom = platform("androidx.compose:compose-bom:2024.10.01")
    implementation(composeBom)
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.activity:activity-compose:1.9.3")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.7")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("androidx.swiperefreshlayout:swiperefreshlayout:1.1.0")
    implementation("androidx.webkit:webkit:1.12.1")
    implementation("androidx.compose.ui:ui-tooling-preview")
    debugImplementation("androidx.compose.ui:ui-tooling")
}
