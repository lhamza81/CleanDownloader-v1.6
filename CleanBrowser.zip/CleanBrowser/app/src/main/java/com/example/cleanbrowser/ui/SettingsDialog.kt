package com.example.cleanbrowser.ui

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.cleanbrowser.AppLock
import com.example.cleanbrowser.download.AppSettings
import com.example.cleanbrowser.download.Storage

@Composable
fun SettingsDialog(onManageAds: (() -> Unit)? = null, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val s by AppSettings.state.collectAsState()

    val folderPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            runCatching {
                ctx.contentResolver.takePersistableUriPermission(
                    uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION,
                )
            }
            AppSettings.update(ctx) { it.copy(folderUri = uri.toString()) }
        }
    }
    val folderName = remember(s.folderUri) { s.folderUri?.let { Storage.folderName(ctx, Uri.parse(it)) } ?: "Downloads" }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Settings") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Download folder", style = MaterialTheme.typography.bodyMedium)
                    Text(folderName, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { AppLock.skipNext = true; folderPicker.launch(null) }) { Text("Choose folder") }
                        if (s.folderUri != null) {
                            TextButton(onClick = { AppSettings.update(ctx) { it.copy(folderUri = null) } }) { Text("Use Downloads") }
                        }
                    }
                }
                NumberRow(
                    "Simultaneous downloads",
                    "Any number you like (1 to 99). A download that gets a new link starts at once, over this number.",
                    s.maxParallel,
                ) { v -> AppSettings.update(ctx) { it.copy(maxParallel = v) } }
                ChoiceRow("Connections per file", "Big files are split over this many connections (up to 8)", listOf(1, 2, 4, 6, 8), s.connections) { v ->
                    AppSettings.update(ctx) { it.copy(connections = v) }
                }
                SwitchRow("Download with Wi-Fi only", "Waiting downloads start when you are on Wi-Fi", s.wifiOnly) { v ->
                    AppSettings.update(ctx) { it.copy(wifiOnly = v) }
                }
                SwitchRow("Block ads", "Drops known ad and tracker sites in the browser", s.blockAds) { v ->
                    AppSettings.update(ctx) { it.copy(blockAds = v) }
                }
                SwitchRow("Block pop-ups and redirects", "Stops pages opening windows or jumping to other sites by themselves", s.blockPopups) { v ->
                    AppSettings.update(ctx) { it.copy(blockPopups = v) }
                }
                SwitchRow("Ask before adding to the ad list", "You confirm before a blocked site is saved in the list", s.askBeforeAdding) { v ->
                    AppSettings.update(ctx) { it.copy(askBeforeAdding = v) }
                }
                if (onManageAds != null) {
                    OutlinedButton(onClick = onManageAds, modifier = Modifier.fillMaxWidth()) { Text("Manage the ad blocker") }
                }
                SwitchRow("Offer copied links", "Asks to open a link you just copied", s.clipboard) { v ->
                    AppSettings.update(ctx) { it.copy(clipboard = v) }
                }
                SwitchRow("Welcome-back screen", "Black at once when you leave the app, and a tap to reopen when you return", s.shield) { v ->
                    AppSettings.update(ctx) { it.copy(shield = v) }
                }
                SwitchRow("Picture in picture", "A playing video stays in a small window when you leave the app", s.pip) { v ->
                    AppSettings.update(ctx) { it.copy(pip = v) }
                }
                SwitchRow("Play in the background", "A page's sound keeps playing when you leave the app or turn off the screen (some sites pause by themselves)", s.bgPlay) { v ->
                    AppSettings.update(ctx) { it.copy(bgPlay = v) }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Done") } },
    )
}

@Composable
private fun SwitchRow(title: String, hint: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyMedium)
            Text(hint, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
private fun NumberRow(title: String, hint: String, value: Int, onChange: (Int) -> Unit) {
    var text by remember(value) { mutableStateOf(value.toString()) }
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text(title, style = MaterialTheme.typography.bodyMedium)
        Text(hint, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        OutlinedTextField(
            value = text,
            onValueChange = { input ->
                val digits = input.filter(Char::isDigit).take(2)
                text = digits
                digits.toIntOrNull()?.takeIf { it >= 1 }?.let(onChange)
            },
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            modifier = Modifier.width(110.dp).padding(top = 2.dp),
        )
    }
}

@Composable
private fun ChoiceRow(title: String, hint: String, options: List<Int>, selected: Int, onPick: (Int) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text(title, style = MaterialTheme.typography.bodyMedium)
        Text(hint, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 2.dp)) {
            options.forEach { n ->
                FilterChip(selected = selected == n, onClick = { onPick(n) }, label = { Text("$n") })
            }
        }
    }
}
