package com.example.cleanbrowser.download

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import org.json.JSONArray
import org.json.JSONObject

enum class DlState { QUEUED, DOWNLOADING, PAUSED, COMPLETED, FAILED }

data class DownloadItem(
    val id: String,
    val url: String,            // MP4 link, or the chosen HLS (.m3u8) playlist
    val pageUrl: String,
    val userAgent: String,
    val name: String,           // base name, no extension
    val state: DlState,
    val uri: String?,           // MediaStore uri of the file
    val downloaded: Long,
    val total: Long,            // -1 if unknown
    val error: String?,
    val createdAt: Long,
    val isHls: Boolean = false,
    val audioUrl: String? = null,   // separate HLS audio playlist, merged into the MP4
    val ext: String = "mp4",         // file type it is saved as (mp4, webm, mkv, mov, flv...)
    val isDash: Boolean = false,    // .mpd stream
    val rep: String? = null,        // the DASH quality chosen
    val expired: Boolean = false,   // the link stopped working (a new one is needed)
    val thumbUrl: String? = null,   // poster picture of the page
    val thumb: String? = null,      // saved preview picture (file path)
    val connections: Int = 1,       // parallel connections used for this file
    val segDone: List<Long>? = null, // bytes done per connection (lets a split download resume)
    val speedBps: Long = 0L,        // live download rate (not saved)
    val note: String? = null,       // e.g. "Converting to MP4…" (not saved)
    val retryAt: Long = 0L,         // when a failed download is retried by itself (not saved)
)

object DownloadStore {
    private const val PREFS = "downloads"
    private const val KEY = "json"

    private var prefs: SharedPreferences? = null
    private val _items = MutableStateFlow<List<DownloadItem>>(emptyList())
    val items: StateFlow<List<DownloadItem>> = _items.asStateFlow()

    /** Emits the file name each time a download finishes (drives the bottom pop-up). */
    val completed = MutableSharedFlow<String>(extraBufferCapacity = 8)

    @Synchronized
    fun init(ctx: Context) {
        if (prefs != null) return
        val p = ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        prefs = p
        // Anything that was running when the app died goes back in the queue and restarts.
        _items.value = load(p).map { if (it.state == DlState.DOWNLOADING) it.copy(state = DlState.QUEUED) else it }
        save()
    }

    // ----- "this link expired, make a new one" requests (shown as a full-screen question) -----

    private val _needsLink = MutableStateFlow<List<String>>(emptyList())
    val needsLink: StateFlow<List<String>> = _needsLink.asStateFlow()
    private val asked = HashSet<String>()

    /** Asks the user, once per download, to reopen the video page for a new link. */
    @Synchronized
    fun requestNewLink(id: String) {
        if (asked.add(id)) _needsLink.update { it + id }
    }

    /** "Not now": the question is not asked again for this download until its link is replaced. */
    fun dismissNewLink(id: String) { _needsLink.update { it - id } }

    @Synchronized
    fun clearAsked(id: String) {
        asked.remove(id)
        _needsLink.update { it - id }
    }

    fun get(id: String): DownloadItem? = _items.value.firstOrNull { it.id == id }

    fun add(item: DownloadItem) { _items.update { listOf(item) + it }; save() }

    /** [persist] is false for frequent progress ticks. */
    fun change(id: String, persist: Boolean = true, f: (DownloadItem) -> DownloadItem) {
        _items.update { list -> list.map { if (it.id == id) f(it) else it } }
        if (persist) save()
    }

    fun remove(id: String) { _items.update { list -> list.filterNot { it.id == id } }; save() }

    private fun save() {
        val arr = JSONArray()
        _items.value.forEach {
            arr.put(JSONObject()
                .put("id", it.id).put("url", it.url).put("page", it.pageUrl).put("ua", it.userAgent)
                .put("name", it.name).put("state", it.state.name).put("uri", it.uri ?: JSONObject.NULL)
                .put("done", it.downloaded).put("total", it.total)
                .put("error", it.error ?: JSONObject.NULL).put("at", it.createdAt)
                .put("hls", it.isHls).put("audio", it.audioUrl ?: JSONObject.NULL)
                .put("ext", it.ext).put("dash", it.isDash).put("rep", it.rep ?: JSONObject.NULL).put("exp", it.expired)
                .put("conns", it.connections).put("segs", JSONArray(it.segDone ?: emptyList<Long>()))
                .put("turl", it.thumbUrl ?: JSONObject.NULL).put("thumb", it.thumb ?: JSONObject.NULL))
        }
        prefs?.edit()?.putString(KEY, arr.toString())?.apply()
    }

    private fun load(p: SharedPreferences): List<DownloadItem> = runCatching {
        val arr = JSONArray(p.getString(KEY, "[]"))
        (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            DownloadItem(
                id = o.getString("id"), url = o.getString("url"), pageUrl = o.optString("page"),
                userAgent = o.optString("ua"), name = o.getString("name"),
                state = runCatching { DlState.valueOf(o.getString("state")) }.getOrDefault(DlState.QUEUED),
                uri = if (o.isNull("uri")) null else o.getString("uri"),
                downloaded = o.optLong("done"), total = o.optLong("total", -1L),
                error = if (o.isNull("error")) null else o.getString("error"),
                createdAt = o.optLong("at"),
                isHls = o.optBoolean("hls", false),
                ext = o.optString("ext", "mp4").ifEmpty { "mp4" },
                isDash = o.optBoolean("dash", false),
                rep = if (o.isNull("rep")) null else o.optString("rep").ifEmpty { null },
                expired = o.optBoolean("exp", false),
                audioUrl = if (o.isNull("audio")) null else o.optString("audio").ifEmpty { null },
                connections = o.optInt("conns", 1),
                thumbUrl = if (o.isNull("turl")) null else o.optString("turl").ifEmpty { null },
                thumb = if (o.isNull("thumb")) null else o.optString("thumb").ifEmpty { null },
                segDone = o.optJSONArray("segs")?.let { a -> (0 until a.length()).map { a.getLong(it) } }?.takeIf { it.isNotEmpty() },
            )
        }
    }.getOrDefault(emptyList())
}
