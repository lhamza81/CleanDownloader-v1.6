package com.example.cleanbrowser.browser

import android.graphics.Bitmap
import android.os.Bundle
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

data class DetectedVideo(
    val url: String,
    val isHls: Boolean = false,      // .m3u8 stream
    val isDash: Boolean = false,     // .mpd stream
    val ext: String = "mp4",         // the container, from the address ("mp4" when it is not known)
    val unknown: Boolean = false,    // the address says nothing about the type: look at what is behind it
)

/** UI-observable state for one tab. The WebView itself lives in [TabManager]. */
class BrowserTab(val id: Int, initialUrl: String) {
    var url by mutableStateOf(initialUrl)
    var title by mutableStateOf("New tab")
    var favicon by mutableStateOf<Bitmap?>(null)
    var progress by mutableIntStateOf(0)
    var canGoBack by mutableStateOf(false)
    var canGoForward by mutableStateOf(false)
    val videos = mutableStateListOf<DetectedVideo>()

    /** Back/forward list + scroll, stored when the WebView is freed to save memory. */
    var savedState: Bundle? = null

    /** Created for window.open()/target=_blank: its WebView must start unused. */
    var isPopup = false

    /** Bumped on every page load so late scans of an old page are ignored. */
    var pageId = 0

    /** A video or audio in this page is playing (reported by the page). */
    var mediaPlaying = false

    /** A pop-up tab whose first address has not been checked yet. */
    var popupCheck = false

    /** Ads removed from this page (for information). */
    var adsRemoved = 0

    /** The tab this one was opened from: closing it (Back) returns there. */
    var openerId = -1

    /** Progress milestones already scanned for videos on this page. */
    var scanStep = 0

    /** Same video (host + path) is kept once, with its newest link because tokens expire. */
    fun addVideo(v: DetectedVideo) {
        val key = VideoDetector.key(v.url)
        val i = videos.indexOfFirst { VideoDetector.key(it.url) == key }
        when {
            i >= 0 -> if (videos[i].url != v.url) videos[i] = v
            videos.size < 50 -> videos.add(v)
        }
    }
}
