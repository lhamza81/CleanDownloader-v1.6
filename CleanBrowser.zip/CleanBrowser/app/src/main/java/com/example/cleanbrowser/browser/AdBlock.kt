package com.example.cleanbrowser.browser

import android.content.Context
import android.content.SharedPreferences
import android.net.Uri
import com.example.cleanbrowser.download.AppSettings
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import org.json.JSONArray

/**
 * Three lists decide what is blocked:
 *  - the built-in list of ad, pop-up and tracker sites,
 *  - the user's own ad list (the database): sites added by hand or confirmed after a blocked pop-up or redirect,
 *  - allowed sites: pages where the user turned the ad blocker off.
 * A request to a listed site (or any of its subdomains) is dropped before it loads.
 */
object AdBlock {
    private val builtin = setOf(
        // ad networks and exchanges
        "doubleclick.net", "googlesyndication.com", "googleadservices.com", "adservice.google.com", "2mdn.net",
        "amazon-adsystem.com", "adnxs.com", "adsrvr.org", "criteo.com", "criteo.net", "pubmatic.com",
        "rubiconproject.com", "openx.net", "advertising.com", "adform.net", "smartadserver.com", "yieldmo.com",
        "teads.tv", "media.net", "bidswitch.net", "casalemedia.com", "contextweb.com", "lijit.com",
        "sharethrough.com", "sovrn.com", "yieldlab.net", "33across.com", "indexww.com", "adtechus.com",
        "serving-sys.com", "flashtalking.com", "mathtag.com", "adroll.com", "rtbhouse.com", "smaato.net",
        "inmobi.com", "mopub.com", "ads.mopub.com", "tapjoy.com", "ironsrc.com", "supersonicads.com",
        "startappservice.com", "fyber.com", "applovin.com", "adcolony.com", "vungle.com", "chartboost.com",
        "unityads.unity3d.com", "mintegral.com", "pangleglobal.com", "ads-twitter.com", "adsymptotic.com",
        // native / recommendation ads
        "taboola.com", "outbrain.com", "mgid.com", "revcontent.com", "zedo.com", "adskeeper.com", "runative.com",
        // pop-up, pop-under and redirect networks
        "popads.net", "popcash.net", "propellerads.com", "propellerclick.com", "exoclick.com", "exdynsrv.com",
        "exosrv.com", "realsrv.com", "trafficjunky.com", "trafficstars.com", "tsyndicate.com", "juicyads.com",
        "adsterra.com", "highperformanceformat.com", "highrevenuegate.com", "effectivegatecpm.com",
        "profitablegatecpm.com", "profitableratecpm.com", "hilltopads.net", "clickadu.com", "clickaine.com",
        "onclickads.net", "bidvertiser.com", "adcash.com", "a-ads.com", "ad-maven.com", "admaven.com",
        "adsco.re", "yllix.com", "plugrush.com", "ero-advertising.com", "popunderjs.com", "pushance.com",
        "richads.com", "monetag.com", "galaksion.com", "evadav.com", "adspyglass.com", "mondiad.com",
        // trackers
        "google-analytics.com", "scorecardresearch.com", "moatads.com", "quantserve.com", "demdex.net",
        "bluekai.com", "krxd.net", "rlcdn.com", "tapad.com", "hotjar.com", "mouseflow.com", "outbrainimg.com",
    )

    // Words in the address of a third-party request that give an ad away.
    private val pathHints = listOf("/pagead/", "adsbygoogle", "/adserver", "popunder", "pop-under", "/advert/", "/banner_ads")

    private val _learned = MutableStateFlow<Set<String>>(emptySet())
    val learned: StateFlow<Set<String>> = _learned.asStateFlow()

    private val _allowed = MutableStateFlow<Set<String>>(emptySet())
    val allowed: StateFlow<Set<String>> = _allowed.asStateFlow()

    private var prefs: SharedPreferences? = null

    val builtinCount: Int get() = builtin.size

    @Synchronized
    fun init(ctx: Context) {
        if (prefs != null) return
        val p = ctx.applicationContext.getSharedPreferences("ads", Context.MODE_PRIVATE)
        prefs = p
        _learned.value = read(p, "learned")
        _allowed.value = read(p, "allowed")
    }

    private fun read(p: SharedPreferences, key: String): Set<String> = runCatching {
        val arr = JSONArray(p.getString(key, "[]"))
        (0 until arr.length()).map { arr.getString(it) }.toSet()
    }.getOrDefault(emptySet())

    private fun save() {
        prefs?.edit()
            ?.putString("learned", JSONArray(_learned.value.toList()).toString())
            ?.putString("allowed", JSONArray(_allowed.value.toList()).toString())
            ?.apply()
    }

    /** "https://www.Example.com/path?x" -> "example.com"; null if it isn't a site name. */
    fun clean(input: String): String? {
        var s = input.trim().lowercase()
        s = s.substringAfter("://").substringBefore('/').substringBefore('?').substringBefore('#').substringBefore(':')
        s = s.removePrefix("www.").trim('.')
        return s.takeIf { it.contains('.') && it.all { c -> c.isLetterOrDigit() || c == '.' || c == '-' } }
    }

    // ----- the user's ad list (database) -----

    fun learn(host: String) {
        val h = clean(host) ?: return
        _learned.update { it + h }
        save()
    }

    fun forget(host: String) { _learned.update { it - host }; save() }

    fun clearLearned() { _learned.value = emptySet(); save() }

    // ----- sites where ads are allowed -----

    fun allowSite(host: String) {
        val h = clean(host) ?: return
        _allowed.update { it + h }
        save()
    }

    fun disallowSite(host: String) { _allowed.update { it - host }; save() }

    fun isSiteAllowed(pageHost: String?): Boolean {
        val h = pageHost?.lowercase()?.removePrefix("www.") ?: return false
        return hit(_allowed.value, h)
    }

    // ----- decisions -----

    /** True if [host] (or a parent domain of it) is in the built-in list or the user's ad list. */
    fun isAdHost(host: String?): Boolean {
        val h = host?.lowercase() ?: return false
        return hit(builtin, h) || hit(_learned.value, h)
    }

    fun looksLikeAd(url: String): Boolean = pathHints.any { url.contains(it, ignoreCase = true) }

    /** The page's own files are never treated as ads, even if the page itself is on a listed site. */
    fun sameSite(a: String?, b: String?): Boolean =
        a != null && b != null && registrable(a) == registrable(b)

    /** Decision for one network request made by the page at [pageHost]. */
    fun shouldBlock(pageHost: String?, url: Uri): Boolean {
        if (!AppSettings.state.value.blockAds) return false
        val host = url.host?.lowercase() ?: return false
        if (isSiteAllowed(pageHost) || sameSite(pageHost, host)) return false
        return isAdHost(host) || looksLikeAd(url.toString())
    }

    private fun hit(set: Set<String>, host: String): Boolean {
        var s = host
        while (true) {
            if (s in set) return true
            val dot = s.indexOf('.')
            if (dot < 0) return false
            s = s.substring(dot + 1)
        }
    }

    /** "ads.example.co.uk" -> "example.co.uk" */
    fun registrable(host: String): String {
        val parts = host.lowercase().removePrefix("www.").split('.').filter { it.isNotEmpty() }
        if (parts.size <= 2) return parts.joinToString(".")
        val second = parts[parts.size - 2]
        val take = if (parts.last().length == 2 && second in setOf("co", "com", "org", "net", "gov", "ac", "edu")) 3 else 2
        return parts.takeLast(take).joinToString(".")
    }
}
