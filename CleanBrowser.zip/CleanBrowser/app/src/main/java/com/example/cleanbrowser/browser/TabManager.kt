package com.example.cleanbrowser.browser

import org.json.JSONObject
import com.example.cleanbrowser.playback.Playback
import androidx.webkit.WebViewFeature
import androidx.webkit.WebViewCompat
import android.widget.Toast
import android.os.SystemClock
import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.Message
import android.util.Patterns
import android.view.View
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import com.example.cleanbrowser.download.AppSettings
import java.io.ByteArrayInputStream
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.runtime.getValue
import org.json.JSONArray
import org.json.JSONTokener
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/**
 * Owns up to [MAX_TABS] tabs. Only [MAX_LIVE_WEBVIEWS] WebViews exist at once (LRU);
 * older ones are serialized with saveState() and destroyed, then lazily rebuilt when selected.
 */
class TabManager(private val appContext: Context) {

    companion object {
        const val MAX_TABS = 30
        const val MAX_LIVE_WEBVIEWS = 10
        const val HOME = "https://www.google.com"
    }

    val tabs = mutableStateListOf<BrowserTab>()
    var activeId by mutableIntStateOf(-1)
        private set
    val activeTab: BrowserTab? get() = tabs.firstOrNull { it.id == activeId }

    var userAgent: String = ""
        private set

    // Fullscreen video (WebChromeClient custom view)
    var customView by mutableStateOf<View?>(null)
        private set
    private var customCallback: WebChromeClient.CustomViewCallback? = null

    fun exitFullscreen() {
        customCallback?.onCustomViewHidden()
        customCallback = null
        customView = null
    }

    /** Recreates tabs from a saved session. WebViews are built lazily, so only the active one costs memory. */
    fun restore(session: SavedSession) {
        session.tabs.take(MAX_TABS).forEach { st ->
            tabs.add(BrowserTab(nextId++, st.url).also { it.title = st.title })
        }
        if (tabs.isEmpty()) { newTab(); return }
        select(tabs[session.active.coerceIn(0, tabs.lastIndex)].id)
    }

    private var nextId = 1
    private val mainHandler = Handler(Looper.getMainLooper())

    // accessOrder = true -> iteration order is least-recently-used first
    private val live = LinkedHashMap<Int, WebView>(8, 0.75f, true)

    // ---------- tab lifecycle ----------

    // Link long-press menu (URL of the pressed link, or null)
    var linkMenu by mutableStateOf<String?>(null)
        private set
    fun dismissLinkMenu() { linkMenu = null }

    private val hrefHandler = Handler(Looper.getMainLooper()) { m ->
        m.data?.getString("url")?.takeIf { it.isNotBlank() }?.let { linkMenu = it }
        true
    }

    /** @return false if the 30-tab limit is reached. */
    fun newTab(url: String = HOME, popup: Boolean = false): Boolean {
        if (tabs.size >= MAX_TABS) return false
        val tab = BrowserTab(nextId++, url).also { it.isPopup = popup; it.openerId = activeId; it.popupCheck = popup }
        tabs.add(tab)
        select(tab.id)
        return true
    }

    fun select(id: Int) {
        if (id == activeId) return
        live[activeId]?.onPause()
        activeId = id
        Playback.webPlaying.value = tabs.firstOrNull { it.id == id }?.mediaPlaying == true
        tabs.firstOrNull { it.id == id }?.let { webViewFor(it).onResume() }
        trimLive()
    }

    fun closeTab(id: Int) {
        val index = tabs.indexOfFirst { it.id == id }
        if (index < 0) return
        val opener = tabs[index].openerId
        live.remove(id)?.let { destroy(it) }
        tabs.removeAt(index)
        when {
            tabs.isEmpty() -> { activeId = -1; newTab() }
            id == activeId -> {
                // Back to the tab this one was opened from, else its neighbour.
                val next = tabs.firstOrNull { it.id == opener } ?: tabs[(index - 1).coerceAtLeast(0)]
                activeId = -1
                select(next.id)
            }
        }
    }

    fun destroyAll() {
        live.values.forEach { destroy(it) }
        live.clear()
        tabs.clear()
    }

    // ---------- WebView access ----------

    /** Returns the tab's WebView, creating/restoring it if it was freed. Detached from any old parent. */
    fun webViewFor(tab: BrowserTab): WebView {
        val wv = live[tab.id] ?: createWebView(tab).also { live[tab.id] = it }
        (wv.parent as? ViewGroup)?.removeView(wv)
        return wv
    }

    fun activeWebView(): WebView? = live[activeId]

    fun goBack() { activeWebView()?.takeIf { it.canGoBack() }?.goBack() }
    fun goForward() { activeWebView()?.takeIf { it.canGoForward() }?.goForward() }
    fun reload() { activeWebView()?.reload() }

    fun stop() {
        activeWebView()?.stopLoading()
        activeTab?.progress = 100
    }

    /**
     * Back: the previous page, or - when there is none - close this tab and return to the one before it.
     * @return false if this is the last tab and it has no history (nothing left to go back to).
     */
    fun backOrClose(): Boolean {
        val wv = activeWebView()
        if (wv != null && wv.canGoBack()) { wv.goBack(); return true }
        if (tabs.size > 1) { closeTab(activeId); return true }
        return false
    }

    fun load(input: String) {
        val url = resolveInput(input)
        activeTab?.url = url
        activeWebView()?.loadUrl(url)
    }

    /** Set while the user is picking a new link for a failed download (the id of that download). */
    var replaceTargetId by mutableStateOf<String?>(null)

    /** True while the "Download video" window is open. */
    var showDownloadDialog by mutableStateOf(false)

    /** A link that is itself a video (.mp4 / .m3u8): list it for download right away. */
    fun openDirectVideo(video: DetectedVideo) {
        activeTab?.let { addVideo(it, video) }
        showDownloadDialog = true
    }

    /** Address bar: direct video links open the download window, anything else is loaded as a page. */
    fun go(input: String) {
        val video = VideoDetector.classify(resolveInput(input))
        if (video != null) openDirectVideo(video) else load(input)
    }

    fun resolveInput(raw: String): String {
        val s = raw.trim()
        if (s.isEmpty()) return HOME
        if (!s.contains(' ') && Patterns.WEB_URL.matcher(s).matches()) {
            return if (s.startsWith("http://") || s.startsWith("https://")) s else "https://$s"
        }
        return "https://www.google.com/search?q=" + Uri.encode(s)
    }

    // ---------- memory management ----------

    private fun trimLive() {
        val it = live.entries.iterator()
        while (live.size > MAX_LIVE_WEBVIEWS && it.hasNext()) {
            val (id, wv) = it.next()
            if (id == activeId) continue
            tabs.firstOrNull { t -> t.id == id }?.savedState = Bundle().also { b -> wv.saveState(b) }
            destroy(wv)
            it.remove()
        }
    }

    private fun destroy(wv: WebView) {
        (wv.parent as? ViewGroup)?.removeView(wv)
        wv.stopLoading()
        wv.webViewClient = WebViewClient()
        wv.webChromeClient = null
        wv.destroy()
    }

    // ---------- WebView construction ----------

    @SuppressLint("SetJavaScriptEnabled")
    private fun createWebView(tab: BrowserTab): WebView {
        // Application context avoids leaking the Activity; swap to MutableContextWrapper later if you need dialogs.
        val wv = WebView(appContext)
        wv.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = true
            mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
            allowFileAccess = false
            allowContentAccess = false
            useWideViewPort = true
            loadWithOverviewMode = true
            setSupportZoom(true)
            setSupportMultipleWindows(true)
            builtInZoomControls = true
            displayZoomControls = false
            // Drop the "; wv" WebView marker so sites serve the normal mobile page.
            userAgentString = userAgentString.replace("; wv", "").replace(" Version/4.0", "")
            if (userAgent.isEmpty()) userAgent = userAgentString
        }
        CookieManager.getInstance().setAcceptThirdPartyCookies(wv, true)
        wv.webViewClient = client(tab)
        wv.webChromeClient = chrome(tab)
        wv.addJavascriptInterface(VideoBridge(tab), "CDBridge")
        wv.addJavascriptInterface(AdBridge(tab), "CDAds")
        // The ad cleaner runs before the page's own scripts where WebView allows it; otherwise it is injected as the page starts.
        if (WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)) {
            runCatching { WebViewCompat.addDocumentStartJavaScript(wv, AdScripts.JS, setOf("*")) }
        }
        wv.setOnLongClickListener { v ->
            val r = (v as WebView).hitTestResult
            when (r.type) {
                WebView.HitTestResult.SRC_ANCHOR_TYPE -> r.extra?.let { linkMenu = it; true } ?: false
                WebView.HitTestResult.SRC_IMAGE_ANCHOR_TYPE -> { v.requestFocusNodeHref(hrefHandler.obtainMessage()); true }
                else -> false
            }
        }

        val restored = tab.savedState?.let { wv.restoreState(it) }
        tab.savedState = null
        if (restored == null && !tab.isPopup) wv.loadUrl(tab.url)
        tab.isPopup = false
        return wv
    }

    private fun sync(tab: BrowserTab, wv: WebView) {
        tab.canGoBack = wv.canGoBack()
        tab.canGoForward = wv.canGoForward()
        wv.title?.takeIf { it.isNotBlank() }?.let { tab.title = it }
        wv.url?.let { tab.url = it }
    }

    // ---------- video scan (finds videos that never show up as network requests) ----------

    private fun scheduleScans(tab: BrowserTab, wv: WebView) {
        val page = tab.pageId
        longArrayOf(100, 400, 900, 1_600, 2_600, 4_000, 6_000, 9_000, 14_000, 20_000).forEach { delay ->
            mainHandler.postDelayed({
                if (live[tab.id] === wv && tab.pageId == page) scan(tab, wv)
            }, delay)
        }
    }

    // ---------- pop-ups, automatic redirects and the ad list ----------

    /** The question "add this site to your ad list?" after a pop-up or redirect was stopped. */
    var adPrompt by mutableStateOf<AdPrompt?>(null)
        private set
    private val recentPrompts = HashMap<String, Long>()

    private fun hostOf(url: String?): String? = runCatching { Uri.parse(url).host }.getOrNull()

    private fun adsOnFor(tab: BrowserTab): Boolean =
        AppSettings.state.value.blockAds && !AdBlock.isSiteAllowed(hostOf(tab.url))

    private fun popupsOnFor(tab: BrowserTab): Boolean = adsOnFor(tab) && AppSettings.state.value.blockPopups

    /** A pop-up or redirect was stopped. Known ad sites stay silent; a new site is offered for the ad list. */
    private fun reportBlocked(tab: BrowserTab, kind: String, url: String) {
        val host = hostOf(url)?.removePrefix("www.")?.takeIf { it.isNotBlank() } ?: return
        if (AdBlock.isAdHost(host)) return
        if (!AppSettings.state.value.askBeforeAdding) {
            AdBlock.learn(host)
            Toast.makeText(appContext, "Added $host to the ad list", Toast.LENGTH_SHORT).show()
            return
        }
        val now = SystemClock.elapsedRealtime()
        if (adPrompt != null || now - (recentPrompts[host] ?: 0L) < 60_000L) return
        recentPrompts[host] = now
        adPrompt = AdPrompt(kind, host, url, tab.id)
    }

    /** "Add to list": the site is saved in the ad database and blocked from now on. */
    fun adPromptAdd() {
        adPrompt?.let { AdBlock.learn(it.host) }
        adPrompt = null
    }

    fun adPromptDismiss() { adPrompt = null }

    /** "Open it": the blocked pop-up or redirect is opened after all. */
    fun adPromptAllow() {
        val p = adPrompt ?: return
        adPrompt = null
        if (p.kind == "redirect") live[p.tabId]?.loadUrl(p.url) else newTab(p.url)
    }

    /** A new pop-up tab whose first address is an ad site is closed before anything shows. @return true if closed. */
    private fun checkPopup(tab: BrowserTab, url: String): Boolean {
        if (!tab.popupCheck || url == "about:blank") return false
        tab.popupCheck = false
        val opener = tabs.firstOrNull { it.id == tab.openerId }
        if (opener != null && popupsOnFor(opener) && AdBlock.isAdHost(hostOf(url))) {
            mainHandler.post { closeTab(tab.id) }
            return true
        }
        return false
    }

    /** A window the page opened without a tap: it is not opened, but its address is read so it can be listed. */
    private fun probePopup(resultMsg: Message, tab: BrowserTab) {
        val probe = WebView(appContext)
        var done = false
        fun finish(url: String?) {
            if (done) return
            done = true
            mainHandler.post {
                runCatching { probe.stopLoading(); probe.destroy() }
                if (!url.isNullOrBlank()) reportBlocked(tab, "pop-up", url)
            }
        }
        probe.webViewClient = object : WebViewClient() {
            // Nothing is really loaded: every request gets an empty answer.
            override fun shouldInterceptRequest(v: WebView, r: WebResourceRequest): WebResourceResponse =
                WebResourceResponse("text/plain", "utf-8", ByteArrayInputStream(ByteArray(0)))

            override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest): Boolean {
                finish(r.url.toString())
                return true
            }

            override fun onPageStarted(v: WebView, url: String, f: Bitmap?) {
                if (url != "about:blank") finish(url)
            }
        }
        (resultMsg.obj as WebView.WebViewTransport).webView = probe
        resultMsg.sendToTarget()
        mainHandler.postDelayed({ finish(null) }, 5_000)
    }

    /** What the scripts inside a page ask the app: is blocking on, is this address an ad, a pop-up was stopped. */
    private inner class AdBridge(private val tab: BrowserTab) {
        @JavascriptInterface
        fun adsOn(): Boolean = adsOnFor(tab)

        @JavascriptInterface
        fun isAd(url: String?): Boolean {
            val u = url ?: return false
            val host = hostOf(u)
            return !AdBlock.sameSite(hostOf(tab.url), host) && (AdBlock.isAdHost(host) || AdBlock.looksLikeAd(u))
        }

        @JavascriptInterface
        fun popup(url: String?) {
            val u = url.orEmpty()
            mainHandler.post { reportBlocked(tab, "pop-up", u) }
        }

        @JavascriptInterface
        fun removed() { tab.adsRemoved++ }
    }

    // ---------- picture-in-picture and playing in the background ----------

    /** True while the app is shown in the small picture-in-picture window. */
    var inPip by mutableStateOf(false)

    fun pauseMedia() {
        activeWebView()?.evaluateJavascript("document.querySelectorAll('video,audio').forEach(function(v){v.pause();});", null)
    }

    fun holdForBackground() { activeWebView()?.evaluateJavascript(VideoScanner.HOLD_JS, null) }

    fun releaseHold() { activeWebView()?.evaluateJavascript(VideoScanner.RELEASE_JS, null) }

    fun enterPipPresentation() { activeWebView()?.evaluateJavascript(VideoScanner.PIP_ON_JS, null) }

    fun exitPipPresentation() { activeWebView()?.evaluateJavascript(VideoScanner.PIP_OFF_JS, null) }

    /** Rescans the open page now (called when the download button is tapped). */
    fun scanActive() {
        val tab = activeTab ?: return
        val wv = activeWebView() ?: return
        scan(tab, wv)
    }

    /** Adds a found video to the tab and starts checking it (resolution, size, length, audio) at once. */
    private fun addVideo(tab: BrowserTab, video: DetectedVideo) {
        tab.addVideo(video)
        VideoProbe.prefetch(video, userAgent, tab.url)
    }

    /** Receives videos reported by the script inside the page. Only video links are accepted. */
    private inner class VideoBridge(private val tab: BrowserTab) {
        @JavascriptInterface
        fun state(playing: Boolean) {
            mainHandler.post {
                tab.mediaPlaying = playing
                if (tab.id == activeId) Playback.webPlaying.value = playing
            }
        }

        @JavascriptInterface
        fun found(url: String?) {
            val video = url?.let { VideoDetector.fromElement(it) } ?: return
            mainHandler.post { addVideo(tab, video) }
        }
    }

    private fun scan(tab: BrowserTab, wv: WebView) {
        val page = tab.pageId
        wv.evaluateJavascript(VideoScanner.JS) { raw ->
            runCatching {
                if (tab.pageId != page) return@runCatching
                val str = JSONTokener(raw).nextValue() as? String ?: return@runCatching
                val o = JSONObject(str)
                o.optJSONArray("u")?.let { a ->
                    for (i in 0 until a.length()) VideoDetector.classify(a.getString(i))?.let { addVideo(tab, it) }
                }
                o.optJSONArray("e")?.let { a ->
                    for (i in 0 until a.length()) VideoDetector.fromElement(a.getString(i))?.let { addVideo(tab, it) }
                }
            }
        }
    }

    private fun client(tab: BrowserTab) = object : WebViewClient() {
        override fun onPageStarted(view: WebView, url: String, favicon: Bitmap?) {
            if (checkPopup(tab, url)) return
            tab.url = url
            tab.pageId++
            tab.mediaPlaying = false
            if (tab.id == activeId) Playback.webPlaying.value = false
            tab.scanStep = 0
            tab.videos.clear()
            view.evaluateJavascript(VideoScanner.WATCHER_JS, null)
            view.evaluateJavascript(AdScripts.JS, null)
            tab.favicon = favicon ?: tab.favicon
            sync(tab, view)
        }

        override fun onPageCommitVisible(view: WebView, url: String) {
            view.evaluateJavascript(VideoScanner.WATCHER_JS, null)
            view.evaluateJavascript(AdScripts.JS, null)
        }

        override fun onPageFinished(view: WebView, url: String) {
            (view.parent as? SwipeRefreshLayout)?.isRefreshing = false
            view.evaluateJavascript(VideoScanner.WATCHER_JS, null)
            view.evaluateJavascript(AdScripts.JS, null)
            sync(tab, view)
            scheduleScans(tab, view)
            if (url.startsWith("http")) {
                Library.history.put(LibraryEntry(view.title?.takeIf { it.isNotBlank() } ?: url, url, System.currentTimeMillis()))
            }
        }

        override fun doUpdateVisitedHistory(view: WebView, url: String, isReload: Boolean) = sync(tab, view)

        // Runs on a background thread. We only observe; returning null lets WebView load normally.
        override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
            if (AdBlock.shouldBlock(hostOf(tab.url), request.url)) {
                return WebResourceResponse("text/plain", "utf-8", ByteArrayInputStream(ByteArray(0)))
            }
            VideoDetector.fromRequest(request.url.toString(), request.requestHeaders)?.let { video ->
                mainHandler.post { addVideo(tab, video) }
            }
            return null
        }

        override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
            val scheme = request.url.scheme?.lowercase()
            if (scheme != "http" && scheme != "https" && scheme != "about") return true
            if (checkPopup(tab, request.url.toString())) return true
            // A page that sends you to another site by itself (no tap, not a server redirect) is stopped.
            if (request.isForMainFrame && popupsOnFor(tab)) {
                val target = request.url.host
                if (!AdBlock.sameSite(hostOf(tab.url), target)) {
                    val unsolicited = !request.hasGesture() && !request.isRedirect
                    if (AdBlock.isAdHost(target) || unsolicited) {
                        reportBlocked(tab, "redirect", request.url.toString())
                        return true
                    }
                }
            }
            return false
        }
    }

    private fun chrome(tab: BrowserTab) = object : WebChromeClient() {
        override fun onProgressChanged(view: WebView, newProgress: Int) {
            tab.progress = newProgress
            if (newProgress >= 100) (view.parent as? SwipeRefreshLayout)?.isRefreshing = false
            // Look for videos at every quarter of the load instead of waiting for the page to finish.
            val step = newProgress / 25
            if (step > tab.scanStep) {
                tab.scanStep = step
                scan(tab, view)
            }
        }
        override fun onReceivedTitle(view: WebView, title: String?) { if (!title.isNullOrBlank()) tab.title = title }
        override fun onReceivedIcon(view: WebView, icon: Bitmap?) { tab.favicon = icon }

        // target=_blank / window.open triggered by a tap opens a new tab. A window the page opens by itself is not
        // opened; where it wanted to go is read so the site can be added to the ad list.
        override fun onCreateWindow(view: WebView, isDialog: Boolean, isUserGesture: Boolean, resultMsg: Message): Boolean {
            if (!isUserGesture) {
                if (popupsOnFor(tab)) {
                    probePopup(resultMsg, tab)
                    return true
                }
                return false
            }
            if (!newTab("about:blank", popup = true)) return false
            val wv = activeWebView() ?: return false
            (resultMsg.obj as WebView.WebViewTransport).webView = wv
            resultMsg.sendToTarget()
            return true
        }

        override fun onShowCustomView(view: View, callback: CustomViewCallback) {
            customCallback?.onCustomViewHidden()
            customView = view
            customCallback = callback
        }

        override fun onHideCustomView() {
            customView = null
            customCallback = null
        }
    }
}

/** A pop-up or automatic redirect that was stopped, waiting for the user's answer. */
data class AdPrompt(val kind: String, val host: String, val url: String, val tabId: Int)
