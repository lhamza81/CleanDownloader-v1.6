package com.example.cleanbrowser.download

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import android.os.Handler
import android.os.Looper
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.min
import kotlin.math.sin

object Beep {
    private const val RATE = 22_050
    private const val SECONDS = 0.8

    private val bell: ShortArray by lazy { buildBell() }

    /** Old mechanical alarm-clock bell, under a second. Follows the phone's silent / vibrate mode. */
    fun play() {
        runCatching {
            val data = bell
            val attributes = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build()
            val format = AudioFormat.Builder()
                .setSampleRate(RATE)
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                .build()
            val track = AudioTrack(attributes, format, data.size * 2, AudioTrack.MODE_STATIC, AudioManager.AUDIO_SESSION_ID_GENERATE)
            track.write(data, 0, data.size)
            track.play()
            Handler(Looper.getMainLooper()).postDelayed({ runCatching { track.release() } }, (SECONDS * 1000).toLong() + 300)
        }
    }

    /** A metallic tone (a few bell partials) struck about 28 times a second, fading out: "brrring". */
    private fun buildBell(): ShortArray {
        val n = (RATE * SECONDS).toInt()
        val out = ShortArray(n)
        val partials = doubleArrayOf(1850.0, 2780.0, 3700.0, 5120.0)
        val weights = doubleArrayOf(1.0, 0.7, 0.5, 0.25)
        for (i in 0 until n) {
            val t = i.toDouble() / RATE
            var v = 0.0
            for (k in partials.indices) v += weights[k] * sin(2 * PI * partials[k] * t)
            val strike = exp(-((t * 28.0) % 1.0) * 7.0)                       // each hammer hit dies away fast
            val fade = if (t > SECONDS - 0.15) (SECONDS - t) / 0.15 else 1.0  // soft end
            val attack = min(1.0, t / 0.004)                                  // no click at the start
            val s = v / 2.45 * strike * fade * attack * 0.8
            out[i] = (s.coerceIn(-1.0, 1.0) * Short.MAX_VALUE).toInt().toShort()
        }
        return out
    }
}
