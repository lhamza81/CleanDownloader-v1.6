package com.example.cleanbrowser.browser

/**
 * Runs in every page (and every frame) at the very start, before the page's own scripts:
 *  - window.open is blocked unless the user tapped, or when it leads to an ad site,
 *  - taps on links to ad sites do nothing,
 *  - ad scripts, frames and pictures are never inserted into the page,
 *  - what is left of known ad boxes is hidden and removed, and invisible full-screen click-catching layers go.
 * It asks the app (CDAds) whether blocking is on for this page and whether an address is an ad.
 */
object AdScripts {
    const val JS = """
    (function(){
      if (window.__cdAds) return;
      window.__cdAds = true;
      var B = window.CDAds;
      function on(){ try{ return !!B && B.adsOn(); }catch(e){ return false; } }
      function isAd(u){ try{ return !!B && B.isAd(String(u)); }catch(e){ return false; } }
      function abs(u){ try{ return new URL(u, location.href).href; }catch(e){ return ''; } }

      /* 1. pop-ups: no tap, or towards an ad site */
      var realOpen = window.open;
      window.open = function(u){
        try{
          if(on()){
            var active = navigator.userActivation ? navigator.userActivation.isActive : true;
            var target = u ? abs(u) : '';
            if(!active || (target && isAd(target))){ B.popup(target); return null; }
          }
        }catch(e){}
        return realOpen.apply(this, arguments);
      };

      /* 2. taps on links that lead to ad sites */
      document.addEventListener('click', function(e){
        try{
          if(!on()) return;
          var a = e.target && e.target.closest ? e.target.closest('a[href]') : null;
          if(a && isAd(a.href)){ e.preventDefault(); e.stopPropagation(); B.popup(a.href); }
        }catch(x){}
      }, true);

      /* 3. ad scripts, frames and pictures never get into the page */
      function adNode(n){
        try{
          if(!n || !n.tagName) return false;
          var t = n.tagName;
          if(t==='SCRIPT'||t==='IFRAME'||t==='IMG'||t==='LINK'||t==='EMBED'){
            var s = n.src || n.href || '';
            return !!s && on() && isAd(abs(s));
          }
        }catch(e){}
        return false;
      }
      var ac = Node.prototype.appendChild;
      Node.prototype.appendChild = function(n){ if(adNode(n)) return n; return ac.apply(this, arguments); };
      var ib = Node.prototype.insertBefore;
      Node.prototype.insertBefore = function(n, r){ if(adNode(n)) return n; return ib.apply(this, arguments); };
      var ap = Element.prototype.append;
      Element.prototype.append = function(){
        var keep = [].filter.call(arguments, function(n){ return !adNode(n); });
        return ap.apply(this, keep);
      };

      /* 4. hide and remove what is left */
      var css = '[id^="google_ads"],[id^="div-gpt-ad"],ins.adsbygoogle,.adsbygoogle,[data-ad-slot],[data-ad-unit],' +
        '[data-google-query-id],iframe[src*="doubleclick.net"],iframe[src*="googlesyndication.com"],iframe[src*="adservice"],' +
        '[class~="ad-banner"],[class~="ad_banner"],[class~="adbox"],[class~="ad-box"],[class~="ad-container"],' +
        '[class~="ad-wrapper"],[class~="advert"],[class~="advertisement"],[class~="sponsored-ad"],' +
        '[id="advertisement"],[id="ad-banner"]{display:none!important;visibility:hidden!important;}';
      function addStyle(){
        if(!on() || document.querySelector('style[data-cd]')) return;
        var st = document.createElement('style');
        st.setAttribute('data-cd', '1');
        st.textContent = css;
        (document.head || document.documentElement).appendChild(st);
      }
      function clean(root){
        try{
          if(!on()) return;
          var base = (root && root.querySelectorAll) ? root : document;
          base.querySelectorAll('iframe[src],script[src],img[src]').forEach(function(n){ if(adNode(n)) n.remove(); });
        }catch(e){}
      }
      function overlays(){
        try{
          if(!on()) return;
          var w = window.innerWidth, h = window.innerHeight;
          document.querySelectorAll('div,a,section,span').forEach(function(n){
            var cs = getComputedStyle(n);
            if(cs.position !== 'fixed' && cs.position !== 'absolute') return;
            if((parseInt(cs.zIndex, 10) || 0) < 1000) return;
            var r = n.getBoundingClientRect();
            if(r.width < w * 0.9 || r.height < h * 0.9) return;
            if((n.innerText || '').trim()) return;
            if(n.querySelector('img,video,iframe,input,button,svg,canvas')) return;
            var clear = parseFloat(cs.opacity) < 0.1 || cs.backgroundColor === 'rgba(0, 0, 0, 0)' || cs.backgroundColor === 'transparent';
            if(clear){ n.remove(); try{ B.removed(); }catch(e){} }
          });
        }catch(e){}
      }
      var pending = false;
      function later(){
        if(pending) return;
        pending = true;
        setTimeout(function(){ pending = false; overlays(); }, 1500);
      }
      addStyle();
      document.addEventListener('DOMContentLoaded', function(){ addStyle(); clean(document); overlays(); });
      try{
        new MutationObserver(function(muts){
          muts.forEach(function(m){
            if(!m.addedNodes) return;
            m.addedNodes.forEach(function(n){ if(n.nodeType === 1){ if(adNode(n)) n.remove(); else clean(n); } });
          });
          later();
        }).observe(document.documentElement, {childList:true, subtree:true});
      }catch(e){}
      [600, 1800, 4000, 8000].forEach(function(t){ setTimeout(overlays, t); });
    })();
    """
}
