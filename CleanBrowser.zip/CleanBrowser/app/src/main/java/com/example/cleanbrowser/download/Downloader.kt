package com.example.cleanbrowser.download

import android.content.Context
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.IOException
import com.example.cleanbrowser.browser.VideoOption

object Downloader {

    /**
     * Starts the download at once. At most 3 run together; further ones wait in the queue and start
     * by themselves. A video that is already queued, paused or finished is reported as DUPLICATE.
     */
    fun enqueue(
        ctx: Context, option: VideoOption, pageUrl: String, userAgent: String, rawName: String,
        thumbUrl: String? = null,
    ): StartResult = DownloadEngine.enqueue(ctx, option, pageUrl, userAgent, rawName, thumbUrl)

    fun retry(id: String) = DownloadEngine.retry(id)

    /** Play button: resume a paused or failed download. */
    fun resume(id: String) = DownloadEngine.retry(id)

    /** Pause button. */
    fun pause(id: String) = DownloadEngine.pause(id)

    fun pauseAll() = DownloadEngine.pauseAll()

    fun resumeAll() = DownloadEngine.resumeAll()

    /** Removes the entry and deletes the file (partial or complete). */
    fun remove(ctx: Context, item: DownloadItem) = DownloadEngine.remove(ctx, item)

    /** Renames a finished file. The name always ends with .mp4. */
    fun rename(ctx: Context, item: DownloadItem, newName: String): Boolean {
        val uri = item.uri?.let { Uri.parse(it) } ?: return false
        val base = FileNames.base(newName)
        val moved = Storage.rename(ctx, uri, "$base.${item.ext}") ?: return false
        DownloadStore.change(item.id) { it.copy(name = base, uri = moved.toString()) }
        return true
    }

    /**
     * Replaces the (expired) link of a download and resumes it without losing what was already downloaded.
     * @return null on success, otherwise a message for the user. A stream (.m3u8) starts again from the beginning.
     */
    suspend fun replaceLink(ctx: Context, id: String, rawUrl: String): String? = withContext(Dispatchers.IO) {
        val url = rawUrl.trim()
        if (!(url.startsWith("http://") || url.startsWith("https://")) || url.contains(' ') || url.contains('\n')) {
            return@withContext "That doesn't look like a web link"
        }
        val item = DownloadStore.get(id) ?: return@withContext "That download no longer exists"
        if (!item.isHls && !item.isDash && item.total > 0) {
            // The saved part only fits the same file: compare sizes before swapping.
            val size = runCatching { remoteSize(item, url) }.getOrNull()
                ?: return@withContext "Couldn't reach the new link. Check it and try again"
            if (size == -2L) return@withContext "That link doesn't lead to a video"
            if (size > 0 && size != item.total) {
                return@withContext "That link is a different file (its size is not the same), so it can't continue this download"
            }
        }
        DownloadEngine.replaceUrl(id, url)
        null
    }

    /** Size of the file behind [url] (-1 unknown, -2 not a video). Reads one byte, not the file. */
    private fun remoteSize(item: DownloadItem, url: String): Long {
        val c = Http.open(url, item.userAgent, item.pageUrl, rangeStart = 0, rangeEnd = 0, timeout = 10_000)
        try {
            val type = c.contentType.orEmpty().lowercase()
            if (type.startsWith("text/") || type.contains("html") || type.contains("json")) return -2L
            return when (val code = c.responseCode) {
                206 -> c.getHeaderField("Content-Range")?.substringAfter('/')?.toLongOrNull() ?: -1L
                200 -> c.contentLengthLong
                else -> throw IOException("HTTP $code")
            }
        } finally {
            c.disconnect()
        }
    }
}
