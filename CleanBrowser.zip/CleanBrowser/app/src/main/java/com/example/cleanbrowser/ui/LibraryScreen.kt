package com.example.cleanbrowser.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ListItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.cleanbrowser.browser.Library
import com.example.cleanbrowser.browser.LibraryEntry
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.time.format.FormatStyle

private fun dayLabel(ms: Long): String {
    val zone = ZoneId.systemDefault()
    val day = Instant.ofEpochMilli(ms).atZone(zone).toLocalDate()
    val today = LocalDate.now(zone)
    return when (day) {
        today -> "Today"
        today.minusDays(1) -> "Yesterday"
        else -> day.format(DateTimeFormatter.ofLocalizedDate(FormatStyle.FULL))
    }
}

private fun timeLabel(ms: Long): String =
    Instant.ofEpochMilli(ms).atZone(ZoneId.systemDefault()).toLocalTime()
        .format(DateTimeFormatter.ofLocalizedTime(FormatStyle.SHORT))

/** Bookmarks (tab 0) and history (tab 1, every page visited, grouped by day with the time of each visit). */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LibraryScreen(initialTab: Int, onOpen: (String) -> Unit, onBack: () -> Unit) {
    var tab by remember { mutableIntStateOf(initialTab) }
    val marks by Library.bookmarks.items.collectAsState()
    val history by Library.history.items.collectAsState()
    var confirmClear by remember { mutableStateOf(false) }
    val groups = remember(history) { history.groupBy { dayLabel(it.time) }.toList() }   // newest day first

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(if (tab == 0) "Bookmarks" else "History") },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") } },
                actions = {
                    if (tab == 1 && history.isNotEmpty()) {
                        IconButton(onClick = { confirmClear = true }) { Icon(Icons.Filled.DeleteSweep, "Clear history") }
                    }
                },
            )
        },
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
    ) { padding ->
        Column(Modifier.padding(padding)) {
            TabRow(selectedTabIndex = tab) {
                Tab(selected = tab == 0, onClick = { tab = 0 }, text = { Text("Bookmarks") })
                Tab(selected = tab == 1, onClick = { tab = 1 }, text = { Text("History") })
            }
            if ((tab == 0 && marks.isEmpty()) || (tab == 1 && history.isEmpty())) {
                Text(if (tab == 0) "No bookmarks yet" else "No history yet", modifier = Modifier.padding(24.dp))
            }
            LazyColumn {
                if (tab == 0) {
                    items(marks, key = { it.url }) { e ->
                        EntryRow(e, null, onOpen) { Library.bookmarks.remove(e.url) }
                    }
                } else {
                    groups.forEach { (label, entries) ->
                        item(key = "day-$label") {
                            Text(
                                label,
                                style = MaterialTheme.typography.titleSmall,
                                color = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 14.dp, bottom = 4.dp),
                            )
                        }
                        items(entries, key = { "${it.url}|${it.time}" }) { e ->
                            EntryRow(e, timeLabel(e.time), onOpen) { Library.history.removeEntry(e) }
                        }
                    }
                }
            }
        }
    }

    if (confirmClear) {
        AlertDialog(
            onDismissRequest = { confirmClear = false },
            title = { Text("Clear all history?") },
            dismissButton = { TextButton(onClick = { confirmClear = false }) { Text("Cancel") } },
            confirmButton = { TextButton(onClick = { Library.history.clear(); confirmClear = false }) { Text("Clear") } },
        )
    }
}

@Composable
private fun EntryRow(e: LibraryEntry, time: String?, onOpen: (String) -> Unit, onRemove: () -> Unit) {
    ListItem(
        overlineContent = if (time != null) ({ Text(time) }) else null,
        headlineContent = { Text(e.title.ifBlank { e.url }, maxLines = 2, overflow = TextOverflow.Ellipsis) },
        supportingContent = { Text(e.url, maxLines = 1, overflow = TextOverflow.Ellipsis) },
        trailingContent = { IconButton(onClick = onRemove) { Icon(Icons.Filled.Close, "Remove") } },
        modifier = Modifier.clickable { onOpen(e.url) },
    )
}
