package com.example.cleanbrowser.download

object FileNames {
    private val EXT = Regex("\\.(mp4|m4v|mov|webm|mkv|flv|avi|wmv|3gp|ogv|mpg|mpeg)\$", RegexOption.IGNORE_CASE)

    /** Cleans a title into a base name (no extension). Keeps punctuation and Unicode. */
    fun base(raw: String): String {
        var s = raw
            .replace(":", " -").replace("|", "-")
            .replace(Regex("[\\\\/*?\"<>\\p{Cntrl}]"), "")
            .replace(Regex("\\s+"), " ")
            .trim()
        // Never double the extension: "clip.mp4" and "clip.MP4.mp4" both become "clip".
        while (EXT.containsMatchIn(s)) s = s.replace(EXT, "").trimEnd()
        s = s.trim('.', ' ').take(150).trim()
        return s.ifBlank { "video" }
    }

    /** The saved file name: the title plus the real file type (mp4, webm, mkv...). */
    fun full(raw: String, ext: String = "mp4"): String = base(raw) + "." + ext
}

/** The file name of a download, with its real extension. */
fun DownloadItem.fileName(): String = FileNames.full(name, ext)
