package com.example.cleanbrowser

import android.Manifest
import android.app.PictureInPictureParams
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.os.Build
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.Lifecycle
import com.example.cleanbrowser.browser.AdBlock
import com.example.cleanbrowser.browser.Library
import com.example.cleanbrowser.browser.TabStore
import com.example.cleanbrowser.download.AppSettings
import com.example.cleanbrowser.download.DownloadEngine
import com.example.cleanbrowser.download.PrivateVault
import com.example.cleanbrowser.playback.Playback
import com.example.cleanbrowser.playback.PlaybackService
import com.example.cleanbrowser.ui.BrowserScreen

class MainActivity : ComponentActivity() {
    private val vm: BrowserViewModel by viewModels()
    private val notifPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) {}

    private var pipRequested = false
    private var cover: View? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        DownloadEngine.init(this)
        Library.init(this)
        PrivateVault.init(this)
        AdBlock.init(this)
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            AppLock.skipNext = true
            notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }

        setContent {
            val dark = isSystemInDarkTheme()
            val ctx = LocalContext.current
            val scheme = when {
                Build.VERSION.SDK_INT >= 31 && dark -> dynamicDarkColorScheme(ctx)
                Build.VERSION.SDK_INT >= 31 -> dynamicLightColorScheme(ctx)
                dark -> darkColorScheme()
                else -> lightColorScheme()
            }
            MaterialTheme(colorScheme = scheme) { BrowserScreen(vm) }
        }
    }

    // ---------- privacy: black the moment the app is left ----------

    private fun shieldOn() = AppSettings.state.value.shield && !pipRequested && !isInPictureInPictureMode

    /** A plain black layer over the app and a "secure" window (blank in recent apps), put up at once. */
    private fun showCover() {
        if (!shieldOn() || cover != null) return
        window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
        val black = View(this).apply {
            setBackgroundColor(android.graphics.Color.BLACK)
            isClickable = true
        }
        cover = black
        addContentView(black, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
    }

    private fun hideCover() {
        cover?.let { (it.parent as? ViewGroup)?.removeView(it) }
        cover = null
        window.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
    }

    // ---------- picture-in-picture ----------

    /** Moves the playing video into a small floating window. @return true if the window opened. */
    fun enterPip(): Boolean {
        if (!packageManager.hasSystemFeature(PackageManager.FEATURE_PICTURE_IN_PICTURE)) return false
        val mgr = vm.tabManager
        // A video inside the page: make it fill the page, so the small window shows only the video.
        if (!Playback.playerPlaying && mgr.customView == null) mgr.enterPipPresentation()
        val params = PictureInPictureParams.Builder().setAspectRatio(Playback.aspect).build()
        pipRequested = true
        val ok = runCatching { enterPictureInPictureMode(params) }.getOrDefault(false)
        if (!ok) {
            pipRequested = false
            mgr.exitPipPresentation()
        }
        return ok
    }

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        val playing = Playback.playerPlaying || vm.tabManager.customView != null || Playback.webPlaying.value
        if (AppSettings.state.value.pip && playing && enterPip()) return
        showCover()          // leaving the app: black at once, before anything else
    }

    override fun onPictureInPictureModeChanged(isInPictureInPictureMode: Boolean, newConfig: Configuration) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        vm.tabManager.inPip = isInPictureInPictureMode
        if (!isInPictureInPictureMode) {
            pipRequested = false
            vm.tabManager.exitPipPresentation()
            // The small window was closed (the app is not on screen): stop the video.
            if (lifecycle.currentState == Lifecycle.State.CREATED) {
                vm.tabManager.pauseMedia()
                vm.tabManager.exitFullscreen()
            }
        }
    }

    // ---------- lifecycle ----------

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) vm.checkClipboard(this)
    }

    override fun onPause() {
        val pip = pipRequested || isInPictureInPictureMode
        val keepPlaying = !pip && AppSettings.state.value.bgPlay && Playback.webPlaying.value
        when {
            pip -> Unit      // the video keeps playing in the small window
            keepPlaying -> {
                vm.tabManager.holdForBackground()
                runCatching { PlaybackService.start(this) }
            }
            else -> vm.tabManager.activeWebView()?.onPause()
        }
        showCover()
        super.onPause()
    }

    override fun onResume() {
        super.onResume()
        hideCover()
        PlaybackService.stop(this)
        vm.tabManager.releaseHold()
        vm.tabManager.activeWebView()?.onResume()
    }

    override fun onStop() {
        TabStore.save(this, vm.tabManager)
        vm.lock()
        super.onStop()
    }
}
