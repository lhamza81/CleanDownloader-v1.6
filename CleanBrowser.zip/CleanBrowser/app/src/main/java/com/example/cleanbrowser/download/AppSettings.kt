package com.example.cleanbrowser.download

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class Settings(
    val wifiOnly: Boolean = false,     // queued downloads wait for an unmetered (Wi-Fi) connection
    val blockAds: Boolean = true,      // block known ad / tracker domains in the browser
    val clipboard: Boolean = true,     // offer to open a link you just copied
    val shield: Boolean = true,        // hide the app in recent apps and show "Welcome back" on return
    val pip: Boolean = true,           // picture-in-picture when you leave the app while a video plays
    val bgPlay: Boolean = true,        // keep a page's sound playing in the background
    val blockPopups: Boolean = true,   // stop pop-ups and automatic redirects
    val askBeforeAdding: Boolean = true, // ask before a blocked site is saved in the ad list
    val maxParallel: Int = 3,          // downloads running at once (any number from 1)
    val connections: Int = 8,          // parallel connections per large file (1-8)
    val folderUri: String? = null,     // picked download folder (null = Downloads)
)

object AppSettings {
    private const val FILE = "settings"
    private val _state = MutableStateFlow(Settings())
    val state: StateFlow<Settings> = _state.asStateFlow()
    private var inited = false

    @Synchronized
    fun init(ctx: Context) {
        if (inited) return
        inited = true
        val p = ctx.applicationContext.getSharedPreferences(FILE, Context.MODE_PRIVATE)
        _state.value = Settings(
            wifiOnly = p.getBoolean("wifi", false),
            blockAds = p.getBoolean("ads", true),
            clipboard = p.getBoolean("clip", true),
            shield = p.getBoolean("shield", true),
            pip = p.getBoolean("pip", true),
            bgPlay = p.getBoolean("bgplay", true),
            blockPopups = p.getBoolean("popups", true),
            askBeforeAdding = p.getBoolean("askads", true),
            maxParallel = p.getInt("parallel", 3).coerceIn(1, 99),
            connections = p.getInt("conns", 8).coerceIn(1, 8),
            folderUri = p.getString("folder", null),
        )
    }

    fun update(ctx: Context, f: (Settings) -> Settings) {
        init(ctx)
        val s = f(_state.value)
        _state.value = s
        val e = ctx.applicationContext.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit()
            .putBoolean("wifi", s.wifiOnly).putBoolean("ads", s.blockAds).putBoolean("clip", s.clipboard).putBoolean("shield", s.shield).putBoolean("pip", s.pip).putBoolean("bgplay", s.bgPlay)
            .putBoolean("popups", s.blockPopups).putBoolean("askads", s.askBeforeAdding)
            .putInt("parallel", s.maxParallel).putInt("conns", s.connections)
        if (s.folderUri == null) e.remove("folder") else e.putString("folder", s.folderUri)
        e.apply()
        DownloadEngine.schedule()      // new limits and the Wi-Fi rule apply at once
    }
}
