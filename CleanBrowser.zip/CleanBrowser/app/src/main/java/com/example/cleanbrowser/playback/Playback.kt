package com.example.cleanbrowser.playback

import android.util.Rational
import com.example.cleanbrowser.browser.TabManager
import kotlinx.coroutines.flow.MutableStateFlow

/** What is playing right now, for picture-in-picture and background playback. */
object Playback {
    @Volatile var manager: TabManager? = null

    /** A video or audio in the open page is playing (reported by the page). */
    val webPlaying = MutableStateFlow(false)

    /** The in-app player is playing. */
    @Volatile var playerPlaying = false

    /** Shape of the small window; follows the in-app player's video. */
    @Volatile var aspect: Rational = Rational(16, 9)

    fun setAspect(w: Int, h: Int) {
        if (w <= 0 || h <= 0) return
        val r = w.toDouble() / h
        aspect = when {
            r > 2.39 -> Rational(239, 100)          // the system only accepts shapes between 1:2.39 and 2.39:1
            r < 1 / 2.39 -> Rational(100, 239)
            else -> Rational(w, h)
        }
    }
}
