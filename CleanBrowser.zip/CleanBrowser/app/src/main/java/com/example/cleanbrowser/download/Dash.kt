package com.example.cleanbrowser.download

import org.w3c.dom.Element
import org.xml.sax.InputSource
import java.io.IOException
import java.io.StringReader
import java.net.URI
import javax.xml.parsers.DocumentBuilderFactory
import kotlin.math.ceil

/** Reads a DASH (.mpd) manifest: the video and audio qualities and the address of every piece. */
object Dash {
    class Rep(
        val id: String, val mime: String, val codecs: String,
        val width: Int, val height: Int, val bandwidth: Long,
        val initUrl: String?, val media: List<String>,   // the pieces, in order
        val single: String?,                              // or one whole file
    ) {
        val pieces: Int get() = if (single != null) 1 else media.size
    }

    class Manifest(
        val video: List<Rep>, val audio: List<Rep>, val seconds: Double?,
        val live: Boolean, val protected: Boolean,
    )

    private val TOKEN = Regex("\\$(RepresentationID|Number|Bandwidth|Time)(?:%0(\\d+)d)?\\$")

    private fun resolve(base: String, ref: String): String = URI(base).resolve(ref).toString()

    private fun children(node: Element, name: String): List<Element> {
        val out = mutableListOf<Element>()
        val list = node.childNodes
        for (i in 0 until list.length) {
            val n = list.item(i)
            if (n is Element && n.nodeName == name) out += n
        }
        return out
    }

    private fun baseOf(node: Element, parent: String): String =
        children(node, "BaseURL").firstOrNull()?.textContent?.trim()?.takeIf { it.isNotEmpty() }
            ?.let { resolve(parent, it) } ?: parent

    private fun seconds(iso: String): Double? {
        if (iso.isBlank()) return null
        val m = Regex("^P(?:(\\d+)D)?(?:T(?:(\\d+)H)?(?:(\\d+)M)?(?:([\\d.]+)S)?)?\$").find(iso) ?: return null
        val d = m.groupValues[1].toDoubleOrNull() ?: 0.0
        val h = m.groupValues[2].toDoubleOrNull() ?: 0.0
        val mi = m.groupValues[3].toDoubleOrNull() ?: 0.0
        val s = m.groupValues[4].toDoubleOrNull() ?: 0.0
        return d * 86400 + h * 3600 + mi * 60 + s
    }

    private fun fill(template: String, id: String, bandwidth: Long, number: Long, time: Long): String =
        TOKEN.replace(template) { m ->
            val width = m.groupValues[2].toIntOrNull() ?: 1
            when (m.groupValues[1]) {
                "RepresentationID" -> id
                "Bandwidth" -> bandwidth.toString()
                "Number" -> number.toString().padStart(width, '0')
                else -> time.toString().padStart(width, '0')
            }
        }

    fun parse(text: String, manifestUrl: String): Manifest {
        val factory = DocumentBuilderFactory.newInstance()
        runCatching { factory.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true) }
        val doc = factory.newDocumentBuilder().parse(InputSource(StringReader(text)))
        val mpd = doc.documentElement
        val live = mpd.getAttribute("type") == "dynamic"
        val total = seconds(mpd.getAttribute("mediaPresentationDuration"))
        val period = children(mpd, "Period").firstOrNull() ?: throw IOException("Empty manifest")
        val periodSeconds = seconds(period.getAttribute("duration")) ?: total
        val periodBase = baseOf(period, baseOf(mpd, manifestUrl))

        var protectedStream = children(mpd, "ContentProtection").isNotEmpty()
        val video = mutableListOf<Rep>()
        val audio = mutableListOf<Rep>()

        for (set in children(period, "AdaptationSet")) {
            if (children(set, "ContentProtection").isNotEmpty()) protectedStream = true
            val setBase = baseOf(set, periodBase)
            for (r in children(set, "Representation")) {
                if (children(r, "ContentProtection").isNotEmpty()) protectedStream = true
                val mime = r.getAttribute("mimeType").ifEmpty { set.getAttribute("mimeType") }
                val type = set.getAttribute("contentType")
                val isVideo = type == "video" || mime.startsWith("video")
                val isAudio = type == "audio" || mime.startsWith("audio")
                if (!isVideo && !isAudio) continue

                val id = r.getAttribute("id")
                val bandwidth = r.getAttribute("bandwidth").toLongOrNull() ?: 0L
                val width = (r.getAttribute("width").ifEmpty { set.getAttribute("width") }).toIntOrNull() ?: 0
                val height = (r.getAttribute("height").ifEmpty { set.getAttribute("height") }).toIntOrNull() ?: 0
                val codecs = r.getAttribute("codecs").ifEmpty { set.getAttribute("codecs") }
                val repBase = baseOf(r, setBase)

                val template = children(r, "SegmentTemplate").firstOrNull() ?: children(set, "SegmentTemplate").firstOrNull()
                val list = children(r, "SegmentList").firstOrNull() ?: children(set, "SegmentList").firstOrNull()
                val rep = when {
                    template != null -> {
                        val timescale = template.getAttribute("timescale").toLongOrNull() ?: 1L
                        val startNumber = template.getAttribute("startNumber").toLongOrNull() ?: 1L
                        val duration = template.getAttribute("duration").toLongOrNull()
                        val mediaT = template.getAttribute("media")
                        val initT = template.getAttribute("initialization")
                        val urls = mutableListOf<String>()
                        val timeline = children(template, "SegmentTimeline").firstOrNull()
                        if (timeline != null) {
                            var number = startNumber
                            var time = 0L
                            for (s in children(timeline, "S")) {
                                s.getAttribute("t").toLongOrNull()?.let { time = it }
                                val d = s.getAttribute("d").toLongOrNull() ?: continue
                                val repeats = s.getAttribute("r").toIntOrNull() ?: 0
                                val count = if (repeats >= 0) repeats + 1
                                else (((periodSeconds ?: 0.0) * timescale - time) / d).toInt().coerceAtLeast(1)
                                for (k in 0 until count) {
                                    urls += resolve(repBase, fill(mediaT, id, bandwidth, number, time))
                                    number++
                                    time += d
                                }
                            }
                        } else if (duration != null && periodSeconds != null) {
                            val count = ceil(periodSeconds * timescale / duration).toInt()
                            for (k in 0 until count) {
                                urls += resolve(repBase, fill(mediaT, id, bandwidth, startNumber + k, k.toLong() * duration))
                            }
                        } else {
                            throw IOException("This kind of stream isn't supported")
                        }
                        val init = if (initT.isNotEmpty()) resolve(repBase, fill(initT, id, bandwidth, 0, 0)) else null
                        Rep(id, mime, codecs, width, height, bandwidth, init, urls, null)
                    }
                    list != null -> {
                        val init = children(list, "Initialization").firstOrNull()?.getAttribute("sourceURL")
                            ?.takeIf { it.isNotEmpty() }?.let { resolve(repBase, it) }
                        val urls = children(list, "SegmentURL").map { resolve(repBase, it.getAttribute("media")) }
                        Rep(id, mime, codecs, width, height, bandwidth, init, urls, null)
                    }
                    repBase != setBase -> Rep(id, mime, codecs, width, height, bandwidth, null, emptyList(), repBase)
                    else -> throw IOException("This kind of stream isn't supported")
                }
                if (isVideo) video += rep else audio += rep
            }
        }
        return Manifest(video, audio, periodSeconds, live, protectedStream)
    }
}
