package com.example.cleanbrowser.playback

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.os.IBinder
import android.os.PowerManager
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

/**
 * Keeps a page's sound playing after you leave the app or turn off the screen: the notification keeps the
 * app alive. It stops by itself a few seconds after the page stops playing.
 */
class PlaybackService : Service() {

    companion object {
        private const val NOTIF_ID = 4102
        private const val CHANNEL = "playback"
        private const val ACTION_PAUSE = "com.example.cleandownloader.PAUSE_MEDIA"

        fun start(ctx: Context) {
            ContextCompat.startForegroundService(ctx, Intent(ctx, PlaybackService::class.java))
        }

        fun stop(ctx: Context) {
            ctx.stopService(Intent(ctx, PlaybackService::class.java))
        }
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var watcher: Job? = null
    private var wake: PowerManager.WakeLock? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_PAUSE) {
            Playback.manager?.pauseMedia()
            stopSelf()
            return START_NOT_STICKY
        }
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel(CHANNEL, "Playback", NotificationManager.IMPORTANCE_LOW))
        startForeground(NOTIF_ID, notification(), ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)

        if (wake == null) {
            wake = getSystemService(PowerManager::class.java)
                .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "CleanDownloader:playback")
                .apply { acquire(4 * 60 * 60 * 1000L) }
        }
        if (watcher?.isActive != true) {
            watcher = scope.launch {
                Playback.webPlaying.collectLatest { playing ->
                    if (!playing) {
                        delay(4_000)
                        stopSelf()
                    }
                }
            }
        }
        return START_NOT_STICKY
    }

    private fun notification(): Notification {
        val open = packageManager.getLaunchIntentForPackage(packageName)?.let {
            PendingIntent.getActivity(this, 0, it, PendingIntent.FLAG_IMMUTABLE)
        }
        val pause = PendingIntent.getService(
            this, 1, Intent(this, PlaybackService::class.java).setAction(ACTION_PAUSE), PendingIntent.FLAG_IMMUTABLE,
        )
        val title = Playback.manager?.activeTab?.title?.takeIf { it.isNotBlank() } ?: "Playing"
        return Notification.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle(title)
            .setContentText("Playing in the background")
            .setContentIntent(open)
            .setOngoing(true)
            .addAction(
                Notification.Action.Builder(
                    Icon.createWithResource(this, android.R.drawable.ic_media_pause), "Pause", pause,
                ).build()
            )
            .build()
    }

    override fun onDestroy() {
        watcher?.cancel()
        scope.cancel()
        runCatching { wake?.release() }
        super.onDestroy()
    }
}
