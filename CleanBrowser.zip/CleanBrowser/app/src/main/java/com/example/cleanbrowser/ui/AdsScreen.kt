package com.example.cleanbrowser.ui

import android.widget.Toast
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ListItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.example.cleanbrowser.browser.AdBlock
import com.example.cleanbrowser.download.AppSettings

/** Full control of the ad blocker: switches, your own ad list (the database), and sites where ads are allowed. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdsScreen(currentHost: String?, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val s by AppSettings.state.collectAsState()
    val learned by AdBlock.learned.collectAsState()
    val allowed by AdBlock.allowed.collectAsState()
    var newHost by remember { mutableStateOf("") }
    var problem by remember { mutableStateOf<String?>(null) }
    var confirmClear by remember { mutableStateOf(false) }

    val site = currentHost?.removePrefix("www.")?.takeIf { it.isNotBlank() }
    val siteAllowed = site != null && allowed.any { site == it || site.endsWith(".$it") }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Ad blocker") },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") } },
            )
        },
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
    ) { padding ->
        LazyColumn(
            modifier = Modifier.padding(padding),
            contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            item {
                ToggleRow("Block ads", "Ads and trackers are removed from the page before it loads", s.blockAds) { v ->
                    AppSettings.update(ctx) { it.copy(blockAds = v) }
                }
            }
            item {
                ToggleRow("Block pop-ups and redirects", "Stops pages opening windows or jumping to other sites by themselves", s.blockPopups) { v ->
                    AppSettings.update(ctx) { it.copy(blockPopups = v) }
                }
            }
            item {
                ToggleRow("Ask before adding to the ad list", "You confirm before a blocked site is saved in the list", s.askBeforeAdding) { v ->
                    AppSettings.update(ctx) { it.copy(askBeforeAdding = v) }
                }
            }
            if (site != null) {
                item {
                    ToggleRow("Allow ads on $site", "Turns the ad blocker off for this site only", siteAllowed) { v ->
                        if (v) AdBlock.allowSite(site)
                        else allowed.filter { site == it || site.endsWith(".$it") }.forEach { AdBlock.disallowSite(it) }
                    }
                }
            }

            item {
                androidx.compose.foundation.layout.Column {
                    Text("Your ad list (${learned.size})", style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.primary)
                    Text(
                        "${AdBlock.builtinCount} sites are already built in. The sites you add here are blocked in every page, pop-up and redirect.",
                        style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
            item {
                androidx.compose.foundation.layout.Column {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = newHost,
                        onValueChange = { newHost = it; problem = null },
                        label = { Text("Site to block, like ads.example.com") },
                        singleLine = true,
                        modifier = Modifier.weight(1f),
                    )
                    Button(onClick = {
                        val host = AdBlock.clean(newHost)
                        if (host == null) {
                            problem = "Enter a site name, like ads.example.com"
                        } else {
                            AdBlock.learn(host)
                            newHost = ""
                            Toast.makeText(ctx, "Added $host", Toast.LENGTH_SHORT).show()
                        }
                    }) { Text("Add") }
                }
                problem?.let { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }
                }
            }
            items(learned.sorted(), key = { "l-$it" }) { host ->
                ListItem(
                    headlineContent = { Text(host) },
                    trailingContent = { IconButton(onClick = { AdBlock.forget(host) }) { Icon(Icons.Filled.Close, "Remove") } },
                )
            }
            if (learned.isNotEmpty()) {
                item { TextButton(onClick = { confirmClear = true }) { Text("Clear my ad list") } }
            }

            item {
                androidx.compose.foundation.layout.Column {
                    Text("Allowed sites (${allowed.size})", style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.primary)
                    Text(
                        "Ads are not blocked on these sites.",
                        style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
            items(allowed.sorted(), key = { "a-$it" }) { host ->
                ListItem(
                    headlineContent = { Text(host) },
                    trailingContent = { IconButton(onClick = { AdBlock.disallowSite(host) }) { Icon(Icons.Filled.Close, "Remove") } },
                )
            }
        }
    }

    if (confirmClear) {
        AlertDialog(
            onDismissRequest = { confirmClear = false },
            title = { Text("Clear your ad list?") },
            text = { Text("The ${learned.size} sites you added will no longer be blocked. The built-in list stays.") },
            dismissButton = { TextButton(onClick = { confirmClear = false }) { Text("Cancel") } },
            confirmButton = { TextButton(onClick = { AdBlock.clearLearned(); confirmClear = false }) { Text("Clear") } },
        )
    }
}

@Composable
private fun ToggleRow(title: String, hint: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        androidx.compose.foundation.layout.Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyMedium)
            Text(hint, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Switch(checked = checked, onCheckedChange = onChange)
    }
}
