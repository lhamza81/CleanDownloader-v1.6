package com.example.cleanbrowser.ui

import com.example.cleanbrowser.playback.Playback
import com.example.cleanbrowser.download.fileName
import com.example.cleanbrowser.MainActivity
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.material.icons.filled.PictureInPictureAlt
import android.app.Activity
import android.content.ClipData
import android.content.Context
import android.content.ClipboardManager
import android.net.Uri
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.ContentPaste
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.DownloadDone
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Public
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Badge
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.ListItem
import androidx.compose.material3.ListItemDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import com.example.cleanbrowser.BrowserViewModel
import com.example.cleanbrowser.browser.BrowserTab
import com.example.cleanbrowser.browser.ClipboardLinks
import com.example.cleanbrowser.browser.Library
import com.example.cleanbrowser.browser.LibraryEntry
import com.example.cleanbrowser.browser.DetectedVideo
import com.example.cleanbrowser.browser.VideoDetector
import com.example.cleanbrowser.browser.TabManager
import com.example.cleanbrowser.download.DlState
import com.example.cleanbrowser.download.DownloadItem
import com.example.cleanbrowser.download.DownloadStore
import com.example.cleanbrowser.download.Downloader
import com.example.cleanbrowser.download.StartResult
import com.example.cleanbrowser.download.FileNames
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

private enum class Screen { Browser, Downloads, Completed, Tabs, Library, Private, Status, Ads }

@Composable
fun BrowserScreen(vm: BrowserViewModel = viewModel()) {
    val mgr = vm.tabManager
    val ctx = LocalContext.current
    val fullscreenView = mgr.customView
    var screen by remember { mutableStateOf(Screen.Browser) }
    var playing by remember { mutableStateOf<PlayRequest?>(null) }
    var libraryTab by remember { mutableIntStateOf(0) }
    val items by DownloadStore.items.collectAsState()
    val activeCount = items.count { it.state != DlState.COMPLETED && it.state != DlState.FAILED }
    val showBar = playing == null && !mgr.inPip &&
        (screen == Screen.Browser || screen == Screen.Downloads || screen == Screen.Completed)
    // The web-link icon in the download lists: open the video's page in a new tab.
    // "Find on page" for a failed download: open its page, then pick the video there to get a fresh link.
    val asks by DownloadStore.needsLink.collectAsState()
    val askItem = asks.firstNotNullOfOrNull { id -> items.firstOrNull { it.id == id && it.state == DlState.FAILED && it.expired } }
    val replaceFromPage: (DownloadItem) -> Unit = { item ->
        mgr.replaceTargetId = item.id
        screen = Screen.Browser
        if (!mgr.newTab(item.pageUrl)) Toast.makeText(ctx, "Tab limit reached (${TabManager.MAX_TABS})", Toast.LENGTH_SHORT).show()
        Toast.makeText(ctx, "Let the video start loading, then tap the download button and pick it", Toast.LENGTH_LONG).show()
    }
    val openPage: (String) -> Unit = { url ->
        screen = Screen.Browser
        if (!mgr.newTab(url)) Toast.makeText(ctx, "Tab limit reached (${TabManager.MAX_TABS})", Toast.LENGTH_SHORT).show()
    }

    BackHandler(enabled = fullscreenView == null && playing == null && screen != Screen.Browser) { screen = Screen.Browser }
    BackHandler(enabled = fullscreenView == null && playing == null && screen == Screen.Browser) {
        // Previous page; with none, close the tab; on the last tab with no history, leave the app.
        if (!mgr.backOrClose()) (ctx as? Activity)?.finish()
    }

    Box(Modifier.fillMaxSize()) {
        Scaffold(
            contentWindowInsets = WindowInsets(0, 0, 0, 0),
            bottomBar = { if (showBar) SectionBar(screen, activeCount) { screen = it } },
        ) { padding ->
            Box(Modifier.padding(padding).fillMaxSize()) {
                when (screen) {
                    Screen.Browser -> BrowserContent(
                        mgr,
                        onTabs = { screen = Screen.Tabs },
                        onLibrary = { t -> libraryTab = t; screen = Screen.Library },
                        onPrivate = { screen = Screen.Private },
                        onStatus = { screen = Screen.Status },
                        onPip = { (ctx as? MainActivity)?.enterPip() },
                        onAds = { screen = Screen.Ads },
                    )
                    Screen.Downloads -> DownloadsScreen(DownloadsMode.Active, onPlay = { playing = it }, onOpenPage = openPage, onReplaceFromPage = replaceFromPage)
                    Screen.Completed -> DownloadsScreen(DownloadsMode.Completed, onPlay = { playing = it }, onOpenPage = openPage, onReplaceFromPage = replaceFromPage)
                    Screen.Library -> LibraryScreen(
                        libraryTab,
                        onOpen = { url -> mgr.load(url); screen = Screen.Browser },
                        onBack = { screen = Screen.Browser },
                    )
                    Screen.Private -> PrivateScreen(onBack = { screen = Screen.Browser }, onPlay = { playing = it })
                    Screen.Status -> StatusScreen(onBack = { screen = Screen.Browser }, onPlay = { playing = it })
                    Screen.Ads -> AdsScreen(
                        currentHost = mgr.activeTab?.url?.let { runCatching { Uri.parse(it).host }.getOrNull() },
                        onBack = { screen = Screen.Browser },
                    )
                    Screen.Tabs -> TabSwitcher(
                        tabs = mgr.tabs,
                        activeId = mgr.activeId,
                        onSelect = { mgr.select(it); screen = Screen.Browser },
                        onClose = { mgr.closeTab(it) },
                        onNew = {
                            if (mgr.newTab()) screen = Screen.Browser
                            else Toast.makeText(ctx, "Tab limit reached (${TabManager.MAX_TABS})", Toast.LENGTH_SHORT).show()
                        },
                        onDismiss = { screen = Screen.Browser },
                    )
                }
            }
        }

        // In-app player (overlay)
        playing?.let { req -> PlayerScreen(req.uri, req.title, inPip = mgr.inPip) { playing = null } }
        // Overlay (not a replacement) so the WebView stays attached and playback continues.
        if (fullscreenView != null) FullscreenVideo(fullscreenView, inPip = mgr.inPip, onExit = mgr::exitFullscreen)

        if (!mgr.inPip) CompletedBubble(
            Modifier.align(Alignment.BottomCenter).padding(bottom = if (showBar) 112.dp else 28.dp),
            onClick = { screen = Screen.Completed },
        )

        if (askItem != null && !vm.locked && !mgr.inPip) {
            LinkExpiredScreen(
                name = askItem.fileName(),
                onReopen = { DownloadStore.dismissNewLink(askItem.id); replaceFromPage(askItem) },
                onLater = { DownloadStore.dismissNewLink(askItem.id) },
            )
        }

        if (vm.locked) WelcomeBack { vm.unlock() }
    }

    // "Link you copied": a direct video link goes straight to the download window, a page opens in a new tab.
    vm.clipboardLink?.let { link ->
        AlertDialog(
            onDismissRequest = vm::dismissClipboard,
            title = { Text("Link you copied") },
            text = { Text(link, maxLines = 4, overflow = TextOverflow.Ellipsis) },
            dismissButton = { TextButton(onClick = vm::dismissClipboard) { Text("Dismiss") } },
            confirmButton = {
                TextButton(onClick = {
                    vm.dismissClipboard()
                    screen = Screen.Browser
                    val direct = VideoDetector.classify(link)
                    if (direct != null) mgr.openDirectVideo(direct)
                    else if (!mgr.newTab(link)) {
                        Toast.makeText(ctx, "Tab limit reached (${TabManager.MAX_TABS})", Toast.LENGTH_SHORT).show()
                    }
                }) { Text("Open") }
            },
        )
    }
}

/** Bottom tabs: Browser, Downloads (in progress), Completed (finished files). */
@Composable
private fun SectionBar(selected: Screen, activeCount: Int, onSelect: (Screen) -> Unit) {
    NavigationBar {
        NavigationBarItem(
            selected = selected == Screen.Browser, onClick = { onSelect(Screen.Browser) },
            icon = { Icon(Icons.Filled.Public, null) }, label = { Text("Browser") },
        )
        NavigationBarItem(
            selected = selected == Screen.Downloads, onClick = { onSelect(Screen.Downloads) },
            icon = {
                BadgedBox(badge = { if (activeCount > 0) Badge { Text("$activeCount") } }) {
                    Icon(Icons.Filled.Download, null)
                }
            },
            label = { Text("Downloads") },
        )
        NavigationBarItem(
            selected = selected == Screen.Completed, onClick = { onSelect(Screen.Completed) },
            icon = { Icon(Icons.Filled.DownloadDone, null) }, label = { Text("Completed") },
        )
    }
}

/** Small sky-blue balloon at the bottom with the name of the video that just finished. */
@Composable
private fun CompletedBubble(modifier: Modifier, onClick: () -> Unit) {
    var visible by remember { mutableStateOf(false) }
    var shown by remember { mutableStateOf("") }
    LaunchedEffect(Unit) {
        DownloadStore.completed.collect { name ->
            shown = name
            visible = true
            delay(3500)
            visible = false
            delay(300)
        }
    }
    AnimatedVisibility(
        visible = visible,
        enter = fadeIn() + slideInVertically { it / 2 },
        exit = fadeOut(),
        modifier = modifier,
    ) {
        Row(
            Modifier.clip(RoundedCornerShape(20.dp))
                .background(Color(0xFF87CEEB))   // sky blue
                .clickable { visible = false; onClick() }
                .padding(horizontal = 14.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(Icons.Filled.CheckCircle, null, tint = Color(0xFF0B3954), modifier = Modifier.size(16.dp))
            Text(
                shown,
                color = Color(0xFF0B3954),
                style = MaterialTheme.typography.labelLarge,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.widthIn(max = 260.dp).padding(start = 6.dp),
            )
        }
    }
}

@Composable
private fun BrowserContent(
    mgr: TabManager,
    onTabs: () -> Unit,
    onLibrary: (Int) -> Unit,
    onPrivate: () -> Unit,
    onStatus: () -> Unit,
    onPip: () -> Unit,
    onAds: () -> Unit,
) {
    val ctx = LocalContext.current
    val tab = mgr.activeTab
    var showSettings by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    Column(Modifier.fillMaxSize()) {
        if (!mgr.inPip) Column(Modifier.statusBarsPadding()) {
            TabStrip(
                tabs = mgr.tabs,
                activeId = mgr.activeId,
                onSelect = { mgr.select(it) },
                onClose = { mgr.closeTab(it) },
                onNew = {
                    if (!mgr.newTab()) Toast.makeText(ctx, "Tab limit reached (${TabManager.MAX_TABS})", Toast.LENGTH_SHORT).show()
                },
                trailing = { BrowserMenu(tab, onLibrary, onPrivate, onStatus, onPip, onAds) { showSettings = true } },
            )
            if (tab != null) AddressRow(tab, mgr, onTabs, onHistory = { onLibrary(1) })
        }

        BoxWithConstraints(Modifier.weight(1f).fillMaxWidth()) {
            val density = LocalDensity.current
            val fabPx = with(density) { 60.dp.toPx() }
            val margin = with(density) { 16.dp.toPx() }
            val maxX = (constraints.maxWidth - fabPx).coerceAtLeast(0f)
            val maxY = (constraints.maxHeight - fabPx).coerceAtLeast(0f)
            // Button position: starts bottom-right, then wherever the user drags it.
            var fabX by remember { mutableFloatStateOf(-1f) }
            var fabY by remember { mutableFloatStateOf(-1f) }
            if (fabX < 0f) { fabX = maxX - margin; fabY = maxY - margin }

            if (tab != null) {
                key(tab.id) {
                    // Pull down at the top of a page: the circular arrow appears, then the page reloads.
                    AndroidView(
                        factory = { c ->
                            val wv = mgr.webViewFor(tab)
                            SwipeRefreshLayout(c).apply {
                                addView(
                                    wv,
                                    ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT),
                                )
                                setOnRefreshListener { wv.reload() }
                                setOnChildScrollUpCallback { _, _ -> wv.scrollY > 0 }
                            }
                        },
                        modifier = Modifier.fillMaxSize(),
                    )
                }
                if (tab.progress in 1..99 && !mgr.inPip) {
                    LinearProgressIndicator(progress = { tab.progress / 100f }, modifier = Modifier.fillMaxWidth())
                }
                if (tab.videos.isNotEmpty() && !mgr.inPip) {
                    DownloadFab(
                        modifier = Modifier
                            .offset { IntOffset(fabX.coerceIn(0f, maxX).roundToInt(), fabY.coerceIn(0f, maxY).roundToInt()) }
                            .pointerInput(maxX, maxY) {
                                detectDragGestures { change, drag ->
                                    change.consume()
                                    fabX = (fabX + drag.x).coerceIn(0f, maxX)
                                    fabY = (fabY + drag.y).coerceIn(0f, maxY)
                                }
                            },
                        onClick = {
                            mgr.scanActive()          // pick up videos that only exist in the page itself
                            mgr.showDownloadDialog = true
                        },
                    )
                }
            }
        }
    }

    if (showSettings) SettingsDialog(onManageAds = { showSettings = false; onAds() }) { showSettings = false }

    mgr.linkMenu?.let { link ->
        AlertDialog(
            onDismissRequest = mgr::dismissLinkMenu,
            title = { Text(link, maxLines = 2, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.titleSmall) },
            text = {
                Column {
                    ListItem(
                        headlineContent = { Text("Open in new tab") },
                        leadingContent = { Icon(Icons.Filled.Add, null) },
                        colors = ListItemDefaults.colors(containerColor = Color.Transparent),
                        modifier = Modifier.clickable {
                            if (!mgr.newTab(link)) Toast.makeText(ctx, "Tab limit reached (${TabManager.MAX_TABS})", Toast.LENGTH_SHORT).show()
                            mgr.dismissLinkMenu()
                        },
                    )
                    ListItem(
                        headlineContent = { Text("Copy link") },
                        leadingContent = { Icon(Icons.Filled.ContentCopy, null) },
                        colors = ListItemDefaults.colors(containerColor = Color.Transparent),
                        modifier = Modifier.clickable {
                            ctx.getSystemService(ClipboardManager::class.java)
                                .setPrimaryClip(ClipData.newPlainText("link", link))
                            ClipboardLinks.markHandled(ctx, link)
                            mgr.dismissLinkMenu()
                        },
                    )
                }
            },
            confirmButton = { TextButton(onClick = mgr::dismissLinkMenu) { Text("Cancel") } },
        )
    }

    mgr.adPrompt?.let { p ->
        AlertDialog(
            onDismissRequest = mgr::adPromptDismiss,
            title = { Text(if (p.kind == "pop-up") "Pop-up blocked" else "Automatic redirect blocked") },
            text = {
                Text(
                    "${p.host} tried to ${if (p.kind == "pop-up") "open a new window" else "send you to another site"} by itself.\n\n" +
                        "Add it to your ad list so it is always blocked from now on?",
                )
            },
            dismissButton = { TextButton(onClick = mgr::adPromptDismiss) { Text("Not now") } },
            confirmButton = {
                Row {
                    TextButton(onClick = mgr::adPromptAllow) { Text("Open it") }
                    TextButton(onClick = mgr::adPromptAdd) { Text("Add to list") }
                }
            },
        )
    }

    if (mgr.showDownloadDialog && tab != null) {
        DownloadOptionsDialog(
            videos = tab.videos,
            pageUrl = tab.url,
            pageTitle = tab.title,
            userAgent = mgr.userAgent,
            webView = mgr.activeWebView(),
            replaceName = mgr.replaceTargetId?.let { id -> DownloadStore.get(id)?.let { it.fileName() } },
            onDismiss = { mgr.showDownloadDialog = false; mgr.replaceTargetId = null },
        ) { option, name, thumbUrl ->
            val target = mgr.replaceTargetId
            if (target != null) {
                // Choosing a new link for a failed download: swap it and carry on from the saved part.
                scope.launch {
                    val problem = Downloader.replaceLink(ctx, target, option.url)
                    Toast.makeText(ctx, problem ?: "Link replaced. The download continues", Toast.LENGTH_LONG).show()
                    if (problem == null) {
                        mgr.replaceTargetId = null
                        mgr.showDownloadDialog = false
                    }
                }
            } else {
                val result = Downloader.enqueue(ctx, option, tab.url, mgr.userAgent, name, thumbUrl)
                Toast.makeText(
                    ctx,
                    when (result) {
                        StartResult.STARTED -> "Download started"
                        StartResult.QUEUED -> "Added to the queue"
                        StartResult.DUPLICATE -> "Already downloaded"
                    },
                    Toast.LENGTH_SHORT,
                ).show()
                mgr.showDownloadDialog = false
            }
        }
    }
}

/** Round download button: drag it anywhere on the page, tap it to open the video list. */
@Composable
private fun DownloadFab(modifier: Modifier, onClick: () -> Unit) {
    Surface(
        modifier = modifier.size(60.dp).clickable(onClick = onClick),
        shape = CircleShape,
        color = MaterialTheme.colorScheme.primaryContainer,
        shadowElevation = 6.dp,
    ) {
        Box(contentAlignment = Alignment.Center) {
            Icon(
                Icons.Filled.Download, "Download video",
                tint = MaterialTheme.colorScheme.onPrimaryContainer,
                modifier = Modifier.size(28.dp),
            )
        }
    }
}

/** The address without "https://", "http://" and "www." ("example.com/" shows as "example.com"). */
private fun displayUrl(url: String): String {
    var s = url.removePrefix("https://").removePrefix("http://").removePrefix("www.")
    if (s.isNotEmpty() && s.indexOf('/') == s.length - 1) s = s.dropLast(1)
    return s
}

private fun readClipboard(ctx: Context): String? = runCatching {
    val clip = ctx.getSystemService(ClipboardManager::class.java).primaryClip ?: return@runCatching null
    if (clip.itemCount == 0) return@runCatching null
    clip.getItemAt(0).coerceToText(ctx)?.toString()?.trim()?.take(500)?.takeIf { it.isNotEmpty() }
}.getOrNull()

/** Small round button for the address row (keeps the row from being squeezed by 48 dp touch targets). */
@Composable
private fun BarButton(onClick: () -> Unit, enabled: Boolean = true, content: @Composable () -> Unit) {
    val tint = if (enabled) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.38f)
    Box(
        Modifier.size(34.dp).clip(CircleShape).clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) { CompositionLocalProvider(LocalContentColor provides tint) { content() } }
}

/** Back, Forward, Home, H (history), the address field with reload / stop inside it, and the tab counter. */
@Composable
private fun AddressRow(tab: BrowserTab, mgr: TabManager, onTabs: () -> Unit, onHistory: () -> Unit) {
    val ctx = LocalContext.current
    val focus = LocalFocusManager.current
    var field by remember(tab.id, tab.url) { mutableStateOf(TextFieldValue(displayUrl(tab.url))) }
    var focused by remember { mutableStateOf(false) }
    var copied by remember { mutableStateOf<String?>(null) }
    val loading = tab.progress in 1..99

    // Tapping the bar selects the whole address and offers the text on the clipboard just below it.
    LaunchedEffect(focused) {
        if (focused) {
            delay(80)
            field = field.copy(selection = TextRange(0, field.text.length))
            copied = readClipboard(ctx)
        } else {
            copied = null
        }
    }

    Column {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            BarButton(onClick = { mgr.backOrClose() }, enabled = tab.canGoBack || mgr.tabs.size > 1) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back")
            }
            BarButton(onClick = { mgr.goForward() }, enabled = tab.canGoForward) {
                Icon(Icons.AutoMirrored.Filled.ArrowForward, "Forward")
            }
            BarButton(onClick = { mgr.load(TabManager.HOME) }) { Icon(Icons.Filled.Home, "Home") }
            BarButton(onClick = onHistory) { Text("H", fontSize = 20.sp, fontWeight = FontWeight.Black) }
            TextField(
                value = field,
                onValueChange = { field = it },
                singleLine = true,
                shape = RoundedCornerShape(28.dp),
                colors = TextFieldDefaults.colors(
                    focusedIndicatorColor = Color.Transparent,
                    unfocusedIndicatorColor = Color.Transparent,
                ),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri, imeAction = ImeAction.Go),
                keyboardActions = KeyboardActions(onGo = {
                    // Unchanged text: reload the page exactly as it was (it may be plain http).
                    if (field.text == displayUrl(tab.url)) mgr.load(tab.url) else mgr.go(field.text)
                    focus.clearFocus()
                }),
                trailingIcon = {
                    BarButton(onClick = { if (loading) mgr.stop() else mgr.reload() }) {
                        Icon(if (loading) Icons.Filled.Close else Icons.Filled.Refresh, if (loading) "Stop" else "Reload")
                    }
                },
                modifier = Modifier.weight(1f).padding(horizontal = 4.dp).onFocusChanged { focused = it.isFocused },
            )
            Box(Modifier.size(34.dp).clip(CircleShape).clickable(onClick = onTabs), contentAlignment = Alignment.Center) {
                Box(
                    Modifier.size(24.dp).border(2.dp, MaterialTheme.colorScheme.onSurfaceVariant, RoundedCornerShape(6.dp)),
                    contentAlignment = Alignment.Center,
                ) { Text("${mgr.tabs.size}", style = MaterialTheme.typography.labelSmall) }
            }
        }

        val offer = copied
        if (focused && offer != null && offer != field.text) {
            Row(
                Modifier.fillMaxWidth().clickable { mgr.go(offer); focus.clearFocus() }
                    .padding(horizontal = 16.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Icon(Icons.Filled.ContentPaste, null, Modifier.size(20.dp))
                Column(Modifier.padding(start = 12.dp)) {
                    Text("Open copied text", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                    Text(offer, style = MaterialTheme.typography.bodyMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }
        }
    }
}

@Composable
private fun FullscreenVideo(view: View, inPip: Boolean, onExit: () -> Unit) {
    val activity = LocalContext.current as Activity
    BackHandler(onBack = onExit)
    DisposableEffect(Unit) {
        val controller = WindowCompat.getInsetsController(activity.window, activity.window.decorView)
        controller.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        controller.hide(WindowInsetsCompat.Type.systemBars())
        onDispose { controller.show(WindowInsetsCompat.Type.systemBars()) }
    }
    Box(Modifier.fillMaxSize().background(Color.Black)) {
        AndroidView(
            factory = { (view.parent as? ViewGroup)?.removeView(view); view },
            modifier = Modifier.fillMaxSize(),
        )
        if (!inPip) {
            IconButton(
                onClick = { (activity as? MainActivity)?.enterPip() },
                modifier = Modifier.align(Alignment.TopEnd).statusBarsPadding().padding(8.dp)
                    .background(Color.Black.copy(alpha = 0.45f), CircleShape),
            ) { Icon(Icons.Filled.PictureInPictureAlt, "Picture in picture", tint = Color.White) }
        }
    }
}

/** The three-dot menu next to "+": bookmarks, history, private folder, WhatsApp status, settings. */
@Composable
private fun BrowserMenu(
    tab: BrowserTab?,
    onLibrary: (Int) -> Unit,
    onPrivate: () -> Unit,
    onStatus: () -> Unit,
    onPip: () -> Unit,
    onAds: () -> Unit,
    onSettings: () -> Unit,
) {
    var open by remember { mutableStateOf(false) }
    val marks by Library.bookmarks.items.collectAsState()
    val playingNow by Playback.webPlaying.collectAsState()
    val marked = tab != null && marks.any { it.url == tab.url }
    Box {
        IconButton(onClick = { open = true }) { Icon(Icons.Filled.MoreVert, "Menu") }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            DropdownMenuItem(
                text = { Text(if (marked) "Remove bookmark" else "Add bookmark") },
                enabled = tab != null,
                onClick = {
                    open = false
                    if (tab != null) {
                        if (marked) Library.bookmarks.remove(tab.url)
                        else Library.bookmarks.put(LibraryEntry(tab.title.ifBlank { tab.url }, tab.url, System.currentTimeMillis()))
                    }
                },
            )
            DropdownMenuItem(text = { Text("Bookmarks") }, onClick = { open = false; onLibrary(0) })
            DropdownMenuItem(text = { Text("History") }, onClick = { open = false; onLibrary(1) })
            DropdownMenuItem(text = { Text("Private folder") }, onClick = { open = false; onPrivate() })
            DropdownMenuItem(text = { Text("WhatsApp status") }, onClick = { open = false; onStatus() })
            DropdownMenuItem(text = { Text("Picture in picture") }, enabled = playingNow, onClick = { open = false; onPip() })
            DropdownMenuItem(text = { Text("Ad blocker") }, onClick = { open = false; onAds() })
            DropdownMenuItem(text = { Text("Settings") }, onClick = { open = false; onSettings() })
        }
    }
}

/** Covers the app after it was in the background. Nothing behind it can be seen or touched. */
@Composable
private fun WelcomeBack(onReopen: () -> Unit) {
    BackHandler {}      // Back does nothing while the screen is shown
    Box(
        Modifier.fillMaxSize().background(Color(0xFF0A1F44)).pointerInput(Unit) { detectTapGestures { } },
        contentAlignment = Alignment.Center,
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(28.dp)) {
            Text(
                "Welcome back", color = Color.White,
                style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold,
            )
            Button(
                onClick = onReopen,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E88E5), contentColor = Color.White),
            ) { Text("Tap here to reopen") }
        }
    }
}

/** Full dark-blue question after a download's link expired: reopen the video page to make a new one? */
@Composable
private fun LinkExpiredScreen(name: String, onReopen: () -> Unit, onLater: () -> Unit) {
    BackHandler(onBack = onLater)
    Box(
        Modifier.fillMaxSize().background(Color(0xFF0A1F44)).pointerInput(Unit) { detectTapGestures { } },
        contentAlignment = Alignment.Center,
    ) {
        Column(
            Modifier.padding(32.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(20.dp),
        ) {
            Text(
                "Download link expired", color = Color.White, textAlign = TextAlign.Center,
                style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold,
            )
            Text(
                name, color = Color.White.copy(alpha = 0.85f), textAlign = TextAlign.Center,
                style = MaterialTheme.typography.bodyMedium, maxLines = 3, overflow = TextOverflow.Ellipsis,
            )
            Text(
                "Reopen the video page to create a new download link? The download continues from where it stopped, and nothing already saved is lost.",
                color = Color.White.copy(alpha = 0.85f), textAlign = TextAlign.Center,
                style = MaterialTheme.typography.bodyMedium,
            )
            Button(
                onClick = onReopen,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E88E5), contentColor = Color.White),
            ) { Text("Reopen the page") }
            TextButton(onClick = onLater) { Text("Not now", color = Color.White) }
        }
    }
}
