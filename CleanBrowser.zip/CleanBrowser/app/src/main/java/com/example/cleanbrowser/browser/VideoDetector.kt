package com.example.cleanbrowser.browser

import android.net.Uri

object VideoDetector {
    /** Video files. ".ts" and ".m4s" are left out on purpose: they are pieces of a stream, not videos. */
    private val FILE_EXT = setOf(
        "mp4", "m4v", "f4v", "mov", "webm", "mkv", "flv", "avi", "wmv", "asf", "3gp", "3g2", "ogv", "mpg", "mpeg",
    )

    /** Addresses that end like this are pictures, code, sound... never videos. */
    private val NOT_VIDEO = setOf(
        "js", "css", "png", "jpg", "jpeg", "gif", "svg", "webp", "ico", "json", "html", "htm", "woff", "woff2",
        "ttf", "txt", "xml", "vtt", "srt", "ts", "m4s", "aac", "mp3", "m4a", "ogg", "wav", "map",
    )

    private fun extOf(path: String?): String {
        val name = path?.lowercase()?.substringAfterLast('/') ?: return ""
        return if ('.' in name) name.substringAfterLast('.') else ""
    }

    private fun byExtension(url: String, path: String?): DetectedVideo? = when (val e = extOf(path)) {
        "m3u8" -> DetectedVideo(url, isHls = true)
        "mpd" -> DetectedVideo(url, isDash = true)
        in FILE_EXT -> DetectedVideo(url, ext = if (e == "m4v" || e == "f4v") "mp4" else e)
        else -> null
    }

    /** Any video file (mp4, webm, mkv, mov, flv...), HLS (.m3u8) or DASH (.mpd) stream, also inside a query parameter. */
    fun classify(url: String): DetectedVideo? = runCatching {
        val uri = Uri.parse(url)
        val scheme = uri.scheme?.lowercase()
        if (scheme != "http" && scheme != "https") return@runCatching null
        byExtension(url, uri.path)?.let { return@runCatching it }
        // ...?src=https://cdn.example.com/video.webm
        for (name in uri.queryParameterNames) {
            val v = uri.getQueryParameter(name) ?: continue
            if (!v.startsWith("http://") && !v.startsWith("https://")) continue
            byExtension(v, Uri.parse(v).path)?.let { return@runCatching it }
        }
        null
    }.getOrNull()

    /** An address that came from a <video> or its <source>: it is a video, whatever the address looks like. */
    fun fromElement(url: String): DetectedVideo? = runCatching {
        val uri = Uri.parse(url)
        val scheme = uri.scheme?.lowercase()
        if (scheme != "http" && scheme != "https") return@runCatching null
        classify(url)?.let { return@runCatching it }
        if (extOf(uri.path) in NOT_VIDEO) return@runCatching null
        DetectedVideo(url, unknown = true)
    }.getOrNull()

    /** A request made by a video element says so in its headers, even when the address has no extension. */
    fun fromRequest(url: String, headers: Map<String, String>?): DetectedVideo? {
        classify(url)?.let { return it }
        val dest = headers?.entries?.firstOrNull { it.key.equals("Sec-Fetch-Dest", ignoreCase = true) }?.value
        return if (dest.equals("video", ignoreCase = true)) fromElement(url) else null
    }

    /** Same video served with different tokens = same key (host + path). */
    fun key(url: String): String {
        val u = Uri.parse(url)
        return ((u.host ?: "") + (u.path ?: "")).lowercase()
    }
}
