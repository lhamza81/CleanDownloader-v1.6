package com.example.cleanbrowser.download

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.ContentResolver
import android.content.ContentValues
import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.Environment
import android.os.SystemClock
import android.provider.MediaStore
import com.example.cleanbrowser.browser.VideoDetector
import com.example.cleanbrowser.browser.VideoOption
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.CoroutineStart
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.awaitCancellation
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.isActive
import kotlinx.coroutines.joinAll
import kotlinx.coroutines.launch
import java.io.File
import java.io.FileDescriptor
import java.io.FileOutputStream
import java.io.IOException
import java.io.InputStream
import java.net.HttpURLConnection
import java.nio.ByteBuffer
import java.nio.channels.FileChannel
import java.util.UUID
import java.util.concurrent.atomic.AtomicLongArray

/** Errors that retrying can't fix (expired link, encrypted stream...). */
private open class FatalDownload(message: String) : IOException(message)

/** The link stopped working (expired, blocked, now an error page): a new link is needed. */
private class ExpiredLink(message: String) : FatalDownload(message)

/** The server answered a Range request with the whole file: split downloads won't work there. */
private class RangeUnsupported : IOException("This server doesn't allow split downloads")

private fun AtomicLongArray.total(): Long {
    var s = 0L
    for (i in 0 until length()) s += get(i)
    return s
}

enum class StartResult { STARTED, QUEUED, DUPLICATE }

/**
 * Runs the downloads: starts immediately, at most [Settings.maxParallel] at once (the user's number, 3 by default), the
 * rest wait in the queue and start by themselves as slots free up. Large MP4 files are fetched over
 * several connections at once. With "Wi-Fi only" on, queued downloads wait for Wi-Fi.
 */
object DownloadEngine {
    const val CHANNEL = "downloads"
    private const val MIN_SPLIT_BYTES = 8L * 1024 * 1024
    private const val RETRY_MS = 60_000L          // failed downloads are retried every minute

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val jobs = HashMap<String, Job>()
    private var appCtx: Context? = null

    @Synchronized
    fun init(ctx: Context) {
        if (appCtx != null) return
        val app = ctx.applicationContext
        appCtx = app
        AppSettings.init(app)
        DownloadStore.init(app)
        // Start waiting downloads as soon as Wi-Fi comes back.
        runCatching {
            app.getSystemService(ConnectivityManager::class.java)
                .registerDefaultNetworkCallback(object : ConnectivityManager.NetworkCallback() {
                    override fun onCapabilitiesChanged(network: Network, caps: NetworkCapabilities) { schedule() }
                    override fun onLost(network: Network) { schedule() }
                })
        }
        schedule()          // restarts anything the last session left unfinished
        scope.launch {      // failed downloads: try again every minute, continuing from the saved bytes
            while (true) {
                delay(5_000)
                retryTick()
            }
        }
    }

    fun enqueue(
        ctx: Context, option: VideoOption, pageUrl: String, userAgent: String, rawName: String,
        thumbUrl: String? = null,
    ): StartResult {
        init(ctx)
        // Same video already queued, running, paused or finished: don't download it twice.
        val key = VideoDetector.key(option.url)
        val duplicate = DownloadStore.items.value.any { it.state != DlState.FAILED && VideoDetector.key(it.url) == key } ||
            PrivateVault.items.value.any { VideoDetector.key(it.url) == key }
        if (duplicate) return StartResult.DUPLICATE

        val item = DownloadItem(
            id = UUID.randomUUID().toString(),
            url = option.url, pageUrl = pageUrl, userAgent = userAgent,
            name = FileNames.base(rawName),
            state = DlState.QUEUED, uri = null, downloaded = 0L, total = -1L,
            error = null, createdAt = System.currentTimeMillis(),
            isHls = option.isHls, audioUrl = option.audioUrl, thumbUrl = thumbUrl,
            ext = option.ext, isDash = option.isDash, rep = option.repId,
        )
        DownloadStore.add(item)
        scope.launch { Thumbs.fetch(ctx.applicationContext, item.id) }
        schedule()
        return if (DownloadStore.get(item.id)?.state == DlState.DOWNLOADING) StartResult.STARTED else StartResult.QUEUED
    }

    fun retry(id: String) {
        DownloadStore.change(id) { it.copy(state = DlState.QUEUED, error = null, expired = false, speedBps = 0L, note = null, retryAt = 0L) }
        schedule()
    }

    /** Pauses one download. A partial MP4 is kept, so resuming continues where it stopped. */
    fun pause(id: String) {
        DownloadStore.change(id) { it.copy(state = DlState.PAUSED, speedBps = 0L, note = null, retryAt = 0L) }
        synchronized(this) { jobs.remove(id) }?.cancel()
        schedule()
    }

    /**
     * Gives a download a new link (the old one expired) and queues it again. The partial file, and for split
     * downloads the progress of every connection, are kept, so an MP4 continues where it stopped.
     */
    fun replaceUrl(id: String, url: String) {
        synchronized(this) { jobs.remove(id) }?.cancel()
        DownloadStore.change(id) {
            it.copy(url = url, state = DlState.QUEUED, error = null, expired = false, retryAt = 0L, speedBps = 0L, note = null)
        }
        DownloadStore.clearAsked(id)
        val ctx = appCtx ?: return
        val item = DownloadStore.get(id) ?: return
        // A download that got a new link starts at once, even if the limit of simultaneous downloads is reached.
        val blocked = AppSettings.state.value.wifiOnly && !isUnmetered(ctx)
        if (!blocked) synchronized(this) { if (!jobs.containsKey(id)) start(ctx, item) }
        if (jobs.isNotEmpty()) runCatching { DownloadService.start(ctx) }
    }

    private fun retryTick() {
        val now = System.currentTimeMillis()
        // An expired link can't be fixed by trying again: it waits for a new link instead.
        DownloadStore.items.value.filter { it.state == DlState.FAILED && !it.expired }.forEach { f ->
            when {
                f.retryAt == 0L -> DownloadStore.change(f.id, persist = false) { it.copy(retryAt = now + RETRY_MS) }
                now >= f.retryAt -> retry(f.id)
            }
        }
    }

    /** Stops everything that is running or waiting. Partial MP4 files are kept for resuming. */
    fun pauseAll() {
        val ids = DownloadStore.items.value
            .filter { it.state == DlState.DOWNLOADING || it.state == DlState.QUEUED }
            .map { it.id }
        ids.forEach { id ->
            DownloadStore.change(id) { it.copy(state = DlState.PAUSED, speedBps = 0L, note = null) }
        }
        val running = synchronized(this) { ids.mapNotNull { jobs.remove(it) } }
        running.forEach { it.cancel() }
        schedule()
    }

    fun resumeAll() {
        DownloadStore.items.value.filter { it.state == DlState.PAUSED }.forEach { p ->
            DownloadStore.change(p.id) { it.copy(state = DlState.QUEUED) }
        }
        schedule()
    }

    fun remove(ctx: Context, item: DownloadItem) {
        synchronized(this) { jobs.remove(item.id) }?.cancel()
        DownloadStore.get(item.id)?.uri?.let { Storage.delete(ctx, Uri.parse(it)) }
        DownloadStore.get(item.id)?.thumb?.let { runCatching { File(it).delete() } }
        runCatching { File(ctx.cacheDir, "dl_${item.id}").deleteRecursively() }
        DownloadStore.remove(item.id)
        schedule()
    }

    private fun isUnmetered(ctx: Context): Boolean {
        val cm = ctx.getSystemService(ConnectivityManager::class.java)
        val caps = cm.getNetworkCapabilities(cm.activeNetwork) ?: return false
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_NOT_METERED)
    }

    @Synchronized
    fun schedule() {
        val ctx = appCtx ?: return
        val s = AppSettings.state.value
        val blocked = s.wifiOnly && !isUnmetered(ctx)
        val queued = DownloadStore.items.value.filter { it.state == DlState.QUEUED && !jobs.containsKey(it.id) }

        // Tell the user why nothing is starting.
        val why = if (blocked) "Waiting for Wi-Fi" else null
        queued.filter { it.note != why }.forEach { q ->
            DownloadStore.change(q.id, persist = false) { it.copy(note = why) }
        }

        val free = s.maxParallel.coerceAtLeast(1) - jobs.size
        if (!blocked && free > 0) {
            queued.sortedBy { it.createdAt }.take(free).forEach { start(ctx, it) }
        }
        if (jobs.isNotEmpty()) runCatching { DownloadService.start(ctx) }
    }

    private fun start(ctx: Context, item: DownloadItem) {
        DownloadStore.change(item.id) { it.copy(state = DlState.DOWNLOADING, error = null, speedBps = 0L, note = null) }
        val job = scope.launch(start = CoroutineStart.LAZY) {
            try {
                when {
                    item.isHls -> transferHls(ctx, item.id)
                    item.isDash -> transferDash(ctx, item.id)
                    else -> transferMp4(ctx, item.id)
                }
            } catch (e: CancellationException) {
                // removed or paused by the user
            } catch (e: Exception) {
                // The slot is freed at once (finally below), so the next waiting download starts without delay.
                val expired = e is ExpiredLink
                DownloadStore.change(item.id) {
                    if (it.state == DlState.DOWNLOADING)
                        it.copy(
                            state = DlState.FAILED, error = e.message ?: "Download failed", speedBps = 0L, note = null,
                            expired = expired, retryAt = if (expired) 0L else System.currentTimeMillis() + RETRY_MS,
                        )
                    else it
                }
                // Expired link: ask (full-screen) to reopen the video page for a new one.
                if (expired && DownloadStore.get(item.id)?.pageUrl?.isNotBlank() == true) DownloadStore.requestNewLink(item.id)
            } finally {
                synchronized(this@DownloadEngine) { jobs.remove(item.id) }
                schedule()
            }
        }
        jobs[item.id] = job
        job.start()
    }

    // =====================================================================
    // MP4: one connection, or several for big files. Resumable, retried when the link drops.
    // =====================================================================

    private fun fileExists(resolver: ContentResolver, uri: Uri): Boolean =
        runCatching { resolver.openFileDescriptor(uri, "r")?.use { true } }.getOrNull() == true

    /** Stops a blocked read quickly when the job is cancelled, by closing the connection. */
    private suspend fun <T> withDisconnect(conn: HttpURLConnection, block: suspend () -> T): T = coroutineScope {
        val watcher = launch { try { awaitCancellation() } finally { conn.disconnect() } }
        try { block() } finally { watcher.cancel() }
    }

    private suspend fun transferMp4(ctx: Context, id: String) {
        var attempt = 0
        var allowSplit = true
        while (true) {
            try {
                mp4Attempt(ctx, id, allowSplit)
                return
            } catch (e: CancellationException) {
                throw e
            } catch (e: RangeUnsupported) {
                // The server ignores Range: start over with one plain connection.
                allowSplit = false
                DownloadStore.get(id)?.uri?.let { Storage.delete(ctx, Uri.parse(it)) }
                DownloadStore.change(id) { it.copy(uri = null, connections = 1, segDone = null, downloaded = 0L) }
            } catch (e: FatalDownload) {
                throw e
            } catch (e: IOException) {
                if (++attempt >= 4) throw e
                delay(1000L shl (attempt - 1))      // 1 s, 2 s, 4 s, then continue from the saved bytes
            }
        }
    }

    private suspend fun mp4Attempt(ctx: Context, id: String, allowSplit: Boolean) {
        var item = DownloadStore.get(id) ?: throw CancellationException("removed")
        val resolver = ctx.contentResolver

        // Continue a split download from its saved per-connection progress.
        val savedUri = item.uri
        val savedParts = item.segDone
        if (item.connections > 1 && savedParts != null && item.total > 0 && savedUri != null) {
            val file = Uri.parse(savedUri)
            if (fileExists(resolver, file)) {
                segmentedDownload(ctx, id, item, file, item.total, item.connections, savedParts)
                return
            }
            DownloadStore.change(id) { it.copy(uri = null, connections = 1, segDone = null, downloaded = 0L) }
            item = DownloadStore.get(id) ?: throw CancellationException("removed")
        }

        // Continue a partial file, or start a new one.
        val existing = item.uri?.let { Uri.parse(it) }
        var offset = existing?.let { u ->
            runCatching { resolver.openFileDescriptor(u, "r")?.use { it.statSize } }.getOrNull()
        } ?: -1L
        val target: Uri = if (existing != null && offset >= 0) existing else {
            offset = 0L
            createPending(ctx, item.fileName()).also { u ->
                DownloadStore.change(id) { it.copy(uri = u.toString()) }
            }
        }

        // Like a download manager: before continuing, check that the saved part really is the start of this file.
        if (offset > 0 && !tailMatches(ctx, item, target, offset)) offset = 0L

        val conn = Http.open(item.url, item.userAgent, item.pageUrl, rangeStart = offset.takeIf { it > 0 })
        try {
            val code = conn.responseCode
            if (code == 416 && offset > 0) { complete(ctx, id, target); return }
            if (code == 403 || code == 404 || code == 410)
                throw ExpiredLink("Link expired or blocked (HTTP $code). Reload the page and try again.")
            var append = offset > 0
            if (append && code == 200) { append = false; offset = 0L }              // server ignored Range: restart
            else if (code !in 200..299) throw IOException("HTTP $code")

            // An error page saved as .mp4 is what makes a file "unplayable": refuse it.
            val type = conn.contentType.orEmpty().lowercase()
            if (type.startsWith("text/") || type.contains("html") || type.contains("json") || type.contains("xml"))
                throw ExpiredLink("The link no longer returns a video (it expired). Reload the page and try again.")

            val total = if (code == 206)
                conn.getHeaderField("Content-Range")?.substringAfter('/')?.toLongOrNull() ?: -1L
            else conn.contentLengthLong
            val startAt = offset
            DownloadStore.change(id, persist = false) { it.copy(downloaded = startAt, total = total) }

            // Big file from the start on a server that takes Range requests: use several connections.
            val parts = AppSettings.state.value.connections.coerceIn(1, 8)
            val canSplit = allowSplit && startAt == 0L && code == 200 && parts > 1 && total >= MIN_SPLIT_BYTES &&
                conn.getHeaderField("Accept-Ranges")?.contains("bytes", ignoreCase = true) == true
            if (canSplit) {
                conn.disconnect()
                segmentedDownload(ctx, id, item, target, total, parts, List(parts) { 0L })
                return
            }

            withDisconnect(conn) { copyMp4(ctx, id, conn, target, append, startAt, total) }
            complete(ctx, id, target)
        } finally {
            conn.disconnect()
        }
    }

    private suspend fun copyMp4(
        ctx: Context, id: String, conn: HttpURLConnection, uri: Uri, append: Boolean, startAt: Long, total: Long,
    ) {
        var done = startAt
        var lastTick = SystemClock.elapsedRealtime()
        var lastDone = done
        var speed = 0.0
        ctx.contentResolver.openFileDescriptor(uri, if (append) "rw" else "rwt")!!.use { pfd ->
            FileOutputStream(pfd.fileDescriptor).use { out ->
                if (append) out.channel.position(startAt)
                conn.inputStream.use { input ->
                    val buf = ByteArray(64 * 1024)
                    while (true) {
                        currentCoroutineContext().ensureActive()
                        val n = input.read(buf)
                        if (n < 0) break
                        out.write(buf, 0, n)
                        done += n
                        val now = SystemClock.elapsedRealtime()
                        if (now - lastTick >= 1000) {
                            val inst = (done - lastDone) * 1000.0 / (now - lastTick)
                            speed = if (speed == 0.0) inst else speed * 0.6 + inst * 0.4
                            lastTick = now
                            lastDone = done
                            val d = done
                            val s = speed.toLong()
                            DownloadStore.change(id, persist = false) { it.copy(downloaded = d, total = total, speedBps = s) }
                        }
                    }
                    out.flush()
                }
            }
        }
        if (total > 0 && done < total) throw IOException("Connection lost")
        val d = done
        DownloadStore.change(id, persist = false) { it.copy(downloaded = d, speedBps = 0L) }
    }

    /** The file is cut into [parts] equal pieces, each fetched over its own connection and written in place. */
    private suspend fun segmentedDownload(
        ctx: Context, id: String, item: DownloadItem, target: Uri, total: Long, parts: Int, startDone: List<Long>,
    ) {
        val segLen = (total + parts - 1) / parts
        val done = AtomicLongArray(parts)
        for (i in 0 until parts) done.set(i, startDone.getOrElse(i) { 0L }.coerceAtLeast(0L))
        DownloadStore.change(id) {
            it.copy(total = total, connections = parts, segDone = List(parts) { i -> done.get(i) }, downloaded = done.total())
        }

        ctx.contentResolver.openFileDescriptor(target, "rw")!!.use { pfd ->
            FileOutputStream(pfd.fileDescriptor).channel.use { channel ->
                coroutineScope {
                    val workers = (0 until parts).map { i ->
                        launch { downloadSegment(i, item, channel, segLen, total, done) }
                    }
                    val monitor = launch { monitorSegments(id, total, parts, done) }
                    workers.joinAll()
                    monitor.cancel()
                }
            }
        }
        if (done.total() < total) throw IOException("Connection lost")
        DownloadStore.change(id, persist = false) { it.copy(downloaded = total, speedBps = 0L) }
        complete(ctx, id, target)
    }

    private suspend fun downloadSegment(
        i: Int, item: DownloadItem, channel: FileChannel, segLen: Long, total: Long, done: AtomicLongArray,
    ) {
        val start = i * segLen
        val end = minOf(start + segLen, total) - 1
        var pos = start + done.get(i)
        var attempt = 0
        val buf = ByteArray(64 * 1024)
        while (pos <= end) {
            try {
                val c = Http.open(item.url, item.userAgent, item.pageUrl, rangeStart = pos, rangeEnd = end)
                try {
                    val code = c.responseCode
                    if (code == 403 || code == 404 || code == 410)
                        throw ExpiredLink("Link expired or blocked (HTTP $code). Reload the page and try again.")
                    if (code != 206) throw RangeUnsupported()
                    withDisconnect(c) {
                        c.inputStream.use { input ->
                            while (pos <= end) {
                                currentCoroutineContext().ensureActive()
                                val n = input.read(buf, 0, minOf(buf.size.toLong(), end - pos + 1).toInt())
                                if (n < 0) break
                                val bb = ByteBuffer.wrap(buf, 0, n)
                                var at = pos
                                while (bb.hasRemaining()) at += channel.write(bb, at)
                                pos += n
                                done.set(i, pos - start)
                            }
                        }
                    }
                } finally {
                    c.disconnect()
                }
                if (pos <= end) throw IOException("Connection lost")
            } catch (e: CancellationException) {
                throw e
            } catch (e: FatalDownload) {
                throw e
            } catch (e: RangeUnsupported) {
                throw e
            } catch (e: IOException) {
                if (++attempt >= 4) throw e
                delay(1000L shl (attempt - 1))
            }
        }
    }

    /** Progress, speed and (every 3 s) the per-connection state that lets a split download resume. */
    private suspend fun monitorSegments(id: String, total: Long, parts: Int, done: AtomicLongArray) {
        var lastTick = SystemClock.elapsedRealtime()
        var lastSum = done.total()
        var lastSave = lastTick
        var speed = 0.0
        while (currentCoroutineContext().isActive) {
            delay(1000)
            val now = SystemClock.elapsedRealtime()
            val sum = done.total()
            val inst = (sum - lastSum) * 1000.0 / (now - lastTick).coerceAtLeast(1)
            speed = if (speed == 0.0) inst else speed * 0.6 + inst * 0.4
            lastTick = now
            lastSum = sum
            val save = now - lastSave >= 3000
            if (save) lastSave = now
            val snapshot = List(parts) { done.get(it) }
            val s = speed.toLong()
            DownloadStore.change(id, persist = save) {
                it.copy(downloaded = sum, total = total, speedBps = s, segDone = snapshot)
            }
        }
    }

    // =====================================================================
    // HLS (.m3u8): download segments, merge audio, remux to MP4 (no re-encode)
    // =====================================================================

    private class HlsPlan(
        val videoInit: String?, val video: List<String>,
        val audioInit: String?, val audio: List<String>?,
    )

    private class HlsProgress(val id: String, val totalSegs: Int) {
        var segs = 0
        var bytes = 0L
        private var lastTick = SystemClock.elapsedRealtime()
        private var lastBytes = 0L
        private var speed = 0.0

        /** A piece that was already saved before a failure: counted, but not part of the speed. */
        fun skip(n: Long, isSegment: Boolean) {
            bytes += n
            lastBytes += n
            if (isSegment) segs++
        }

        fun add(n: Long, isSegment: Boolean) {
            bytes += n
            if (isSegment) segs++
            val now = SystemClock.elapsedRealtime()
            if (now - lastTick >= 1000 || (isSegment && segs == totalSegs)) {
                val inst = (bytes - lastBytes) * 1000.0 / (now - lastTick).coerceAtLeast(1)
                speed = if (speed == 0.0) inst else speed * 0.6 + inst * 0.4
                lastTick = now
                lastBytes = bytes
                // Size isn't known up front: estimate it from the share of segments done.
                val b = bytes
                val estimate = if (segs > 0) maxOf(b, b * totalSegs / segs) else -1L
                val s = speed.toLong()
                DownloadStore.change(id, persist = false) { it.copy(downloaded = b, total = estimate, speedBps = s) }
            }
        }
    }

    private fun loadPlan(item: DownloadItem): HlsPlan {
        var text = Http.text(item.url, item.userAgent, item.pageUrl)
        var base = item.url
        var audioUrl = item.audioUrl
        if (Hls.isMaster(text)) {
            val master = Hls.parseMaster(text, base)
            val best = master.variants.maxByOrNull { it.bandwidth }
                ?: throw FatalDownload("No video qualities found in this stream")
            audioUrl = audioUrl ?: master.audioFor(best)
            base = best.url
            text = Http.text(base, item.userAgent, item.pageUrl)
        }
        val v = Hls.parseMedia(text, base)
        if (v.encrypted) throw FatalDownload("This stream is encrypted and can't be saved")
        if (v.live) throw FatalDownload("Live streams can't be saved")
        if (v.byteRange || v.segments.isEmpty()) throw FatalDownload("This kind of stream isn't supported")
        val a = audioUrl
            ?.let { u -> runCatching { Hls.parseMedia(Http.text(u, item.userAgent, item.pageUrl), u) }.getOrNull() }
            ?.takeIf { it.usable }
        return HlsPlan(v.initUrl, v.segments, a?.initUrl, a?.segments)
    }

    private fun pieceDir(ctx: Context, id: String) = File(ctx.cacheDir, "dl_$id").also { it.mkdirs() }

    /** Pieces saved for a stream with a different number of pieces belong to another quality: start clean. */
    private fun checkPieceMeta(dir: File, tag: String) {
        val meta = File(dir, "meta")
        if (!meta.exists() || meta.readText() != tag) {
            dir.listFiles()?.forEach { it.delete() }
            meta.writeText(tag)
        }
    }

    /** Downloads every piece (start piece + segments) into [dir] and joins them into [out]. Saved pieces are kept. */
    private suspend fun fetchPieces(
        prefix: String, initUrl: String?, segs: List<String>, dir: File, out: File, item: DownloadItem, p: HlsProgress,
    ) {
        suspend fun piece(name: String, url: String, isSegment: Boolean) {
            val f = File(dir, name)
            if (f.exists() && f.length() > 0) { p.skip(f.length(), isSegment); return }
            val data = fetchSegment(url, item)
            val part = File(dir, "$name.part")
            part.writeBytes(data)
            part.renameTo(f)
            p.add(data.size.toLong(), isSegment)
        }
        if (initUrl != null) piece(prefix + "_init", initUrl, false)
        segs.forEachIndexed { i, u ->
            currentCoroutineContext().ensureActive()
            piece(prefix + "_" + i.toString().padStart(6, '0'), u, true)
        }
        out.outputStream().buffered().use { os ->
            if (initUrl != null) File(dir, prefix + "_init").inputStream().use { it.copyTo(os) }
            for (i in segs.indices) File(dir, prefix + "_" + i.toString().padStart(6, '0')).inputStream().use { it.copyTo(os) }
        }
    }

    private suspend fun transferHls(ctx: Context, id: String) {
        val item = DownloadStore.get(id) ?: throw CancellationException("removed")
        val resolver = ctx.contentResolver
        val dir = pieceDir(ctx, id)
        val tmpVideo = File(dir, "video.join")
        val tmpAudio = File(dir, "audio.join")
        var target: Uri? = null
        try {
            item.uri?.let { Storage.delete(ctx, Uri.parse(it)) }
            DownloadStore.change(id) { it.copy(uri = null) }

            val plan = loadPlan(item)
            checkPieceMeta(dir, "${plan.video.size}/${plan.audio?.size ?: 0}")
            val progress = HlsProgress(id, plan.video.size + (plan.audio?.size ?: 0))
            fetchPieces("v", plan.videoInit, plan.video, dir, tmpVideo, item, progress)
            plan.audio?.let { fetchPieces("a", plan.audioInit, it, dir, tmpAudio, item, progress) }

            DownloadStore.change(id, persist = false) { it.copy(note = "Converting to MP4…", speedBps = 0L) }
            val out = createPending(ctx, item.fileName())
            target = out
            DownloadStore.change(id) { it.copy(uri = out.toString()) }
            resolver.openFileDescriptor(out, "rwt")!!.use { pfd ->
                remux(tmpVideo, tmpAudio.takeIf { plan.audio != null }, pfd.fileDescriptor)
            }
            complete(ctx, id, out)
            runCatching { dir.deleteRecursively() }
        } catch (e: Exception) {
            target?.let { Storage.delete(ctx, it) }
            DownloadStore.change(id) { it.copy(uri = null) }
            throw e
        } finally {
            // The joined copies go; the pieces stay, so a retry or a new link only fetches what is missing.
            runCatching { tmpVideo.delete(); tmpAudio.delete() }
        }
    }

    // =====================================================================
    // DASH (.mpd): same idea as HLS, with separate video and audio
    // =====================================================================

    /** One whole file (a DASH BaseURL): streamed, and continued from the bytes already saved. */
    private suspend fun downloadSingle(url: String, dest: File, item: DownloadItem, p: HlsProgress) {
        var offset = if (dest.exists()) dest.length() else 0L
        val conn = Http.open(url, item.userAgent, item.pageUrl, rangeStart = offset.takeIf { it > 0 })
        try {
            val code = conn.responseCode
            if (code == 403 || code == 404 || code == 410)
                throw ExpiredLink("Stream link expired or blocked (HTTP $code). Reload the page and try again.")
            if (code == 416 && offset > 0) return
            var append = offset > 0
            if (append && code == 200) { append = false; offset = 0L }
            else if (code !in 200..299) throw IOException("HTTP $code")
            if (offset > 0) p.skip(offset, false)
            withDisconnect(conn) {
                FileOutputStream(dest, append).use { out ->
                    conn.inputStream.use { input ->
                        val buf = ByteArray(64 * 1024)
                        while (true) {
                            currentCoroutineContext().ensureActive()
                            val n = input.read(buf)
                            if (n < 0) break
                            out.write(buf, 0, n)
                            p.add(n.toLong(), false)
                        }
                    }
                }
            }
            p.add(0L, true)
        } finally {
            conn.disconnect()
        }
    }

    /** @return the file to merge: the joined pieces, or the single saved file. */
    private suspend fun fetchRep(prefix: String, rep: Dash.Rep, dir: File, joined: File, item: DownloadItem, p: HlsProgress): File {
        val single = rep.single
        if (single != null) {
            val file = File(dir, prefix + "_single")
            downloadSingle(single, file, item, p)
            return file
        }
        fetchPieces(prefix, rep.initUrl, rep.media, dir, joined, item, p)
        return joined
    }

    private suspend fun transferDash(ctx: Context, id: String) {
        val item = DownloadStore.get(id) ?: throw CancellationException("removed")
        val resolver = ctx.contentResolver
        val dir = pieceDir(ctx, id)
        val tmpVideo = File(dir, "video.join")
        val tmpAudio = File(dir, "audio.join")
        var target: Uri? = null
        try {
            item.uri?.let { Storage.delete(ctx, Uri.parse(it)) }
            DownloadStore.change(id) { it.copy(uri = null) }

            val manifest = Dash.parse(Http.text(item.url, item.userAgent, item.pageUrl), item.url)
            if (manifest.protected) throw FatalDownload("This stream is protected and can't be saved")
            if (manifest.live) throw FatalDownload("Live streams can't be saved")
            val video = manifest.video.firstOrNull { it.id == item.rep }
                ?: manifest.video.maxByOrNull { it.bandwidth }
                ?: throw FatalDownload("No video found in this stream")
            val audio = manifest.audio.maxByOrNull { it.bandwidth }

            checkPieceMeta(dir, "dash:${video.id}:${video.pieces}/${audio?.id}:${audio?.pieces ?: 0}")
            val progress = HlsProgress(id, video.pieces + (audio?.pieces ?: 0))
            val videoFile = fetchRep("v", video, dir, tmpVideo, item, progress)
            val audioFile = audio?.let { fetchRep("a", it, dir, tmpAudio, item, progress) }

            DownloadStore.change(id, persist = false) { it.copy(note = "Converting…", speedBps = 0L) }
            val out = createPending(ctx, item.fileName())
            target = out
            DownloadStore.change(id) { it.copy(uri = out.toString()) }
            resolver.openFileDescriptor(out, "rwt")!!.use { pfd ->
                remux(videoFile, audioFile, pfd.fileDescriptor, webm = item.ext == "webm")
            }
            complete(ctx, id, out)
            runCatching { dir.deleteRecursively() }
        } catch (e: Exception) {
            target?.let { Storage.delete(ctx, it) }
            DownloadStore.change(id) { it.copy(uri = null) }
            throw e
        } finally {
            runCatching { tmpVideo.delete(); tmpAudio.delete() }
        }
    }

    // =====================================================================
    // Continuing a saved part (like a download manager)
    // =====================================================================

    private fun readFully(input: InputStream, n: Int): ByteArray {
        val buf = ByteArray(n)
        var off = 0
        while (off < n) {
            val r = input.read(buf, off, n - off)
            if (r < 0) break
            off += r
        }
        return if (off == n) buf else buf.copyOf(off)
    }

    /** Compares the last bytes of the saved part with the same bytes on the server. A different file must not be continued. */
    private fun tailMatches(ctx: Context, item: DownloadItem, local: Uri, offset: Long): Boolean {
        if (offset < 4096) return true
        return runCatching {
            val n = minOf(offset, 8192L).toInt()
            val start = offset - n
            val c = Http.open(item.url, item.userAgent, item.pageUrl, rangeStart = start, rangeEnd = offset - 1, timeout = 15_000)
            val remote = try {
                if (c.responseCode != 206) return@runCatching true       // no Range support: the normal checks handle it
                c.inputStream.use { readFully(it, n) }
            } finally {
                c.disconnect()
            }
            val saved = ctx.contentResolver.openInputStream(local)?.use { stream ->
                var skipped = 0L
                while (skipped < start) {
                    val k = stream.skip(start - skipped)
                    if (k <= 0) break
                    skipped += k
                }
                readFully(stream, n)
            }
            saved != null && remote.size == n && saved.size == n && remote.contentEquals(saved)
        }.getOrDefault(true)        // if the check itself can't run, trust the saved part
    }

    private suspend fun fetchSegment(url: String, item: DownloadItem): ByteArray {
        var attempt = 0
        while (true) {
            try {
                val c = Http.open(url, item.userAgent, item.pageUrl, timeout = 15_000)
                try {
                    val code = c.responseCode
                    if (code == 403 || code == 404 || code == 410)
                        throw ExpiredLink("Stream link expired or blocked (HTTP $code). Reload the page and try again.")
                    if (code !in 200..299) throw IOException("HTTP $code")
                    return c.inputStream.readBytes()
                } finally {
                    c.disconnect()
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: FatalDownload) {
                throw e
            } catch (e: IOException) {
                if (++attempt >= 3) throw e
                delay(800L * attempt)
            }
        }
    }

    /** Video file (+ optional separate audio file) -> one MP4, without re-encoding. */
    private fun remux(video: File, audio: File?, fd: FileDescriptor, webm: Boolean = false) {
        val videoEx = MediaExtractor()
        var audioEx: MediaExtractor? = null
        var muxer: MediaMuxer? = null
        var started = false
        try {
            videoEx.setDataSource(video.absolutePath)
            val m = MediaMuxer(
                fd,
                if (webm) MediaMuxer.OutputFormat.MUXER_OUTPUT_WEBM else MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4,
            )
            muxer = m

            val videoMap = HashMap<Int, Int>()
            var hasVideo = false
            var videoFileHasAudio = false
            for (i in 0 until videoEx.trackCount) {
                val format = videoEx.getTrackFormat(i)
                val mime = format.getString(MediaFormat.KEY_MIME) ?: continue
                if (!mime.startsWith("video/") && !mime.startsWith("audio/")) continue
                // A codec the MP4 muxer doesn't accept is skipped instead of failing everything.
                val track = runCatching { m.addTrack(format) }.getOrNull() ?: continue
                videoEx.selectTrack(i)
                videoMap[i] = track
                if (mime.startsWith("video/")) hasVideo = true else videoFileHasAudio = true
            }
            if (!hasVideo) throw IOException("No playable video in this stream")

            val audioMap = HashMap<Int, Int>()
            if (audio != null && !videoFileHasAudio) {
                runCatching {
                    val ex = MediaExtractor()
                    audioEx = ex
                    ex.setDataSource(audio.absolutePath)
                    for (i in 0 until ex.trackCount) {
                        val format = ex.getTrackFormat(i)
                        if (format.getString(MediaFormat.KEY_MIME)?.startsWith("audio/") != true) continue
                        val track = runCatching { m.addTrack(format) }.getOrNull() ?: continue
                        ex.selectTrack(i)
                        audioMap[i] = track
                    }
                }
            }

            m.start()
            started = true
            copySamples(videoEx, videoMap, m)
            audioEx?.let { if (audioMap.isNotEmpty()) copySamples(it, audioMap, m) }
        } finally {
            runCatching { if (started) muxer?.stop() }
            runCatching { muxer?.release() }
            videoEx.release()
            audioEx?.release()
        }
    }

    private fun copySamples(ex: MediaExtractor, map: Map<Int, Int>, muxer: MediaMuxer) {
        val buf = ByteBuffer.allocate(4 shl 20)
        val info = MediaCodec.BufferInfo()
        while (true) {
            buf.clear()
            val size = ex.readSampleData(buf, 0)
            if (size < 0) break
            val track = map[ex.sampleTrackIndex]
            if (track != null) {
                val key = ex.sampleFlags and MediaExtractor.SAMPLE_FLAG_SYNC != 0
                info.set(0, size, ex.sampleTime.coerceAtLeast(0), if (key) MediaCodec.BUFFER_FLAG_KEY_FRAME else 0)
                muxer.writeSampleData(track, buf, info)
            }
            ex.advance()
        }
    }

    // =====================================================================
    // Files and notifications
    // =====================================================================

    private fun createPending(ctx: Context, fileName: String): Uri = Storage.create(ctx, fileName)

    private fun complete(ctx: Context, id: String, uri: Uri) {
        val resolver = ctx.contentResolver
        Storage.finish(ctx, uri)
        val size = runCatching { resolver.openFileDescriptor(uri, "r")?.use { it.statSize } }.getOrNull() ?: 0L
        val item = DownloadStore.get(id) ?: return
        DownloadStore.change(id) {
            it.copy(
                state = DlState.COMPLETED, uri = uri.toString(), downloaded = size, total = size,
                speedBps = 0L, note = null, connections = 1, segDone = null,
            )
        }
        val name = item.fileName()
        DownloadStore.completed.tryEmit(name)
        Beep.play()                                   // one short beep per finished file

        ensureChannel(ctx)
        val n = Notification.Builder(ctx, CHANNEL)
            .setSmallIcon(android.R.drawable.stat_sys_download_done)
            .setContentTitle(name)
            .setContentText("Download complete")
            .setAutoCancel(true)
            .build()
        ctx.getSystemService(NotificationManager::class.java).notify(id.hashCode(), n)
    }

    fun ensureChannel(ctx: Context) {
        ctx.getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel(CHANNEL, "Downloads", NotificationManager.IMPORTANCE_LOW))
    }
}
