package com.example.cleanbrowser.browser

/** Scripts that run inside the page. */
object VideoScanner {

    /**
     * Installed in every page. Reports a video the moment it is added to the page or starts loading,
     * and tells the app when the page starts or stops playing sound. Safe to run more than once.
     */
    const val WATCHER_JS = """
    (function(){
      if (window.__cdWatch) return;
      window.__cdWatch = true;
      function rep(u){ try{ if(u && window.CDBridge) CDBridge.found(new URL(u, location.href).href); }catch(e){} }
      function inVideo(s){ return s && s.parentNode && s.parentNode.tagName === 'VIDEO'; }
      function check(v){ rep(v.currentSrc); rep(v.src); rep(v.getAttribute && v.getAttribute('data-src')); }
      ['loadstart','loadedmetadata','play','playing'].forEach(function(ev){
        document.addEventListener(ev, function(e){
          var t = e.target;
          if(t && t.tagName === 'VIDEO') check(t);
          else if(t && t.tagName === 'SOURCE' && inVideo(t)) rep(t.src);
        }, true);
      });
      try{
        new MutationObserver(function(muts){
          muts.forEach(function(m){
            if(!m.addedNodes) return;
            m.addedNodes.forEach(function(n){
              if(n.nodeType !== 1) return;
              if(n.tagName === 'VIDEO') check(n);
              else if(n.tagName === 'SOURCE' && inVideo(n)) rep(n.src);
              else if(n.querySelectorAll) n.querySelectorAll('video,video source').forEach(function(x){
                if(x.tagName === 'VIDEO') check(x); else rep(x.src);
              });
            });
          });
        }).observe(document.documentElement, {childList:true, subtree:true});
      }catch(e){}
      function anyPlaying(){
        try{ return [].slice.call(document.querySelectorAll('video,audio')).some(function(x){ return !x.paused && !x.ended; }); }
        catch(e){ return false; }
      }
      function st(p){ try{ if(window.CDBridge) CDBridge.state(!!p); }catch(e){} }
      ['play','playing'].forEach(function(ev){
        document.addEventListener(ev, function(e){
          var t = e.target;
          if(t && (t.tagName === 'VIDEO' || t.tagName === 'AUDIO')) st(true);
        }, true);
      });
      ['pause','ended','emptied'].forEach(function(ev){
        document.addEventListener(ev, function(e){
          var t = e.target;
          if(t && (t.tagName === 'VIDEO' || t.tagName === 'AUDIO')) st(anyPlaying());
        }, true);
      });
      document.querySelectorAll('video').forEach(check);
      if(anyPlaying()) st(true);
    })();
    """

    /**
     * Looks through the page once. Returns {"u":[...],"e":[...]}: "u" are links that end like a video,
     * "e" are the addresses of <video> elements (any address, they are videos by definition).
     */
    const val JS = """
    (function(){
      var out = {}, el = {};
      var EXT = /\.(mp4|m4v|f4v|mov|webm|mkv|flv|avi|wmv|asf|3gp|3g2|ogv|mpg|mpeg|m3u8|mpd)${'$'}/i;
      function ok(p){ return EXT.test(p); }
      function add(u, forced){
        try{
          if(!u) return;
          var a = new URL(u, location.href);
          if(a.protocol !== 'http:' && a.protocol !== 'https:') return;
          if(forced){ el[a.href] = 1; return; }
          if(ok(a.pathname)){ out[a.href] = 1; return; }
          a.searchParams.forEach(function(v){
            if(/^https?:\/\//i.test(v)){ try{ if(ok(new URL(v).pathname)) out[v] = 1; }catch(e){} }
          });
        }catch(e){}
      }
      document.querySelectorAll('video').forEach(function(v){
        add(v.currentSrc, true); add(v.src, true); add(v.getAttribute('data-src'), true);
      });
      document.querySelectorAll('video source').forEach(function(s){ add(s.src, true); add(s.getAttribute('data-src'), true); });
      document.querySelectorAll('a[href]').forEach(function(a){ add(a.href, false); });
      document.querySelectorAll('meta[property^="og:video"], meta[name^="twitter:player:stream"]').forEach(function(m){ add(m.content, false); });
      return JSON.stringify({u: Object.keys(out), e: Object.keys(el)});
    })()
    """

    /** Keeps a page playing while the app is in the background: the page is told it is still visible. */
    const val HOLD_JS = """
    (function(){
      if (window.__cdHold) return;
      var h = function(e){ e.stopImmediatePropagation(); };
      window.__cdHold = h;
      document.addEventListener('visibilitychange', h, true);
      document.addEventListener('webkitvisibilitychange', h, true);
      try{
        Object.defineProperty(document, 'hidden', {configurable:true, get:function(){ return false; }});
        Object.defineProperty(document, 'visibilityState', {configurable:true, get:function(){ return 'visible'; }});
      }catch(e){}
    })();
    """

    const val RELEASE_JS = """
    (function(){
      var h = window.__cdHold;
      if (!h) return;
      document.removeEventListener('visibilitychange', h, true);
      document.removeEventListener('webkitvisibilitychange', h, true);
      try{ delete document.hidden; delete document.visibilityState; }catch(e){}
      window.__cdHold = null;
    })();
    """

    /** Picture-in-picture for a video inside the page: the video fills the page, so the small window shows only it. */
    const val PIP_ON_JS = """
    (function(){
      var vs = [].slice.call(document.querySelectorAll('video'));
      var v = vs.filter(function(x){ return !x.paused && !x.ended; })[0] || vs[0];
      if(!v) return;
      if(!window.__cdPip){ window.__cdPip = {v: v, style: v.getAttribute('style'), overflow: document.documentElement.style.overflow}; }
      v.style.cssText = 'position:fixed!important;left:0!important;top:0!important;width:100vw!important;height:100vh!important;' +
        'max-width:none!important;max-height:none!important;z-index:2147483647!important;background:#000!important;' +
        'object-fit:contain!important;margin:0!important;transform:none!important;';
      document.documentElement.style.overflow = 'hidden';
    })();
    """

    const val PIP_OFF_JS = """
    (function(){
      var p = window.__cdPip;
      if(!p) return;
      if(p.style === null) p.v.removeAttribute('style'); else p.v.setAttribute('style', p.style);
      document.documentElement.style.overflow = p.overflow;
      window.__cdPip = null;
    })();
    """
}
